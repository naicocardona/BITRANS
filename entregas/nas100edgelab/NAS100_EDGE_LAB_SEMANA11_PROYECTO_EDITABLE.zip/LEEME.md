# NAS100 EDGE LAB · Semana #11 · Proyecto editable

- `s11-tiktok/` y `s11-shorts/`: composiciones HyperFrames 0.8.134 (HTML + GSAP). Para volver a renderizar, entra a la carpeta y ejecuta:
  `npx --yes hyperframes@0.8.134 render --fps 30 -o render.mp4`
- `portada/`: portada editable (1080 × 1920).
- `voz/`: narración de la voz A del Explorador por versión, con los tiempos de cada frase y el texto exacto de cada frase.
- `scripts/`: generadores (composición, mezcla de música y efectos, brillo de ojos).
- Los audios van en FLAC (sin pérdida) para que el ZIP pese menos de 30 MB.
