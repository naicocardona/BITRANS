# Une las frases de la voz A con pausas controladas y aplica la cadena ffmpeg oficial
import numpy as np, soundfile as sf, json, subprocess
SEQ={"tiktok":[("a1",0.3),("a2",0.3),("c1",0.6),("c2",0.3),("c3",0.3),("r1a",0.6),("r1b",0.3),("r1c",0.3),("r2a",0.6),("r2b",0.3),("r2c",0.3),("r3a",0.6),("r3b",0.3),("e1",0.6),("e2",0.3)],
     "shorts":[("a1",0.3),("a2",0.3),("s3",0.5),("s4",0.5),("s5",0.5),("s6",0.25),("s7",0.5),("e1",0.5),("s8",0.3)]}
for v,seq in SEQ.items():
    out=[]; st=[]; t=0.0; sr=None
    for name,gap in seq:
        x,sr=sf.read(f"{name}.wav"); nz=np.where(np.abs(x)>0.004)[0]; x=x[max(0,nz[0]-240):nz[-1]+480]
        out.append(np.zeros(int(gap*sr))); t+=gap; st.append([name,round(t,3),round(len(x)/sr,3)]); out.append(x); t+=len(x)/sr
    out.append(np.zeros(int(0.3*sr)))
    sf.write(f"{v}_raw.wav",np.concatenate(out),sr)
    subprocess.run(["ffmpeg","-loglevel","error","-y","-i",f"{v}_raw.wav","-af","asetrate=24000*0.917,aresample=48000,atempo=1.0905,highpass=f=70,equalizer=f=220:t=q:w=1:g=2,equalizer=f=3000:t=q:w=1.2:g=2.5,deesser=i=0.3,acompressor=threshold=-20dB:ratio=3:attack=5:release=120:makeup=2,aecho=0.85:0.6:35|60:0.18|0.10",f"{v}_narr.wav"],check=True)
    json.dump(st,open(f"{v}_times.json","w")); print(v,round(t+0.3,2))
