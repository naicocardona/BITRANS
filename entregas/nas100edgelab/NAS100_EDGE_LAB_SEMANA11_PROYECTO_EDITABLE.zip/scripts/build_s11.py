# NAS100 EDGE LAB · REPORTE SEMANAL #11 (semana sin operaciones) · TikTok y YouTube Shorts con la voz A del Explorador
# Uso: build_s11.py → scratchpad/s11-tiktok y scratchpad/s11-shorts
import os, json, re, shutil, numpy as np, soundfile as sf
SCR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
AV = "/home/user/BITRANS/entregas/nas100edgelab/avatar/explorador/V3"
TTS = f"{SCR}/s11/tts"
POSES = {"neutral": "bases/avatar_neutral", "explica": "bases/avatar_explica", "senala": "bases/avatar_senala",
         "pensativo": "bases/avatar_pensativo", "satisfecho": "bases/avatar_satisfecho",
         "habla_2": "habla_2", "habla_3": "habla_3", "senala_t1": "senala_t1", "senala_t2": "senala_t2",
         "tp_t1": "tp_t1", "tp_t2": "tp_t2", "piensa_t1": "piensa_t1", "piensa_t2": "piensa_t2",
         "gira_1": "gira_1", "gira_2": "gira_2", "gira_3": "gira_3"}
OVER = {"explica_c": "explica_ojos_cerrados", "senala_c": "senala_ojos_cerrados", "pensativo_c": "pensativo_ojos_cerrados",
        "satisfecho_c": "satisfecho_ojos_cerrados"}
GLOW = ["neutral", "explica", "senala", "pensativo", "satisfecho", "senala_t1", "senala_t2", "tp_t1", "tp_t2", "piensa_t1", "piensa_t2", "gira_1"]
TEXTO = {
 "a1": "Esta semana no hubo entradas,|ni Take Profits, ni Stop Losses.",
 "a2": "Pero una semana sin operaciones|también tiene un lugar en este registro.",
 "c1": "NAS100 EDGE LAB documenta|lo que realmente hacemos.",
 "c2": "Esta semana no operamos,|así que no añadimos resultados.",
 "c3": "Lo que sí podemos explicar es cómo|se interpreta una semana sin actividad.",
 "r1a": "Esta semana no amplía|nuestra muestra de trades.",
 "r1b": "Los resultados anteriores|siguen siendo los mismos.",
 "r1c": "No podemos afirmar que la estrategia|mejoró o empeoró|con datos que no generamos.",
 "r2a": "Cero operaciones no significa|<b class='r'>0 %</b> de acierto.",
 "r2b": "El win rate necesita trades|para calcularse.",
 "r2c": "Esta semana corresponde mostrar <b class='t'>«no aplica»</b>,|igual que en los promedios|de recorrido favorable y adverso.",
 "r3a": "Un registro completo también muestra|cuándo no hubo actividad.",
 "r3b": "Así, quien sigue el laboratorio|puede conocer la frecuencia real de las operaciones,|además de sus ganancias y pérdidas.",
 "e1": "Esta semana no sumamos trades.",
 "e2": "Cuando haya una nueva operación,|volveremos a documentar la entrada,|el resultado y los aprendizajes con datos reales.",
 "s3": "Esta semana no operamos,|así que no añadimos resultados.",
 "s4": "Primero: sin operaciones no hay nueva evidencia;|la muestra de trades no creció.",
 "s5": "Segundo: cero operaciones no significa|<b class='r'>0 %</b> de acierto.",
 "s6": "Sin trades, el win rate <b class='t'>no aplica</b>.",
 "s7": "Tercero: las pausas también forman parte del historial|y muestran la frecuencia real de las operaciones.",
 "s8": "Cuando haya una nueva operación,|volveremos a documentarla con datos reales.",
}
VAR = {
 "tiktok": dict(ch=["GANCHO", "CONTEXTO", "REFLEXIÓN 1", "REFLEXIÓN 2", "REFLEXIÓN 3", "CIERRE"], ENDSUB=""),
 "shorts": dict(ch=["GANCHO", "CONTEXTO", "REFLEXIÓN 1", "REFLEXIÓN 2", "REFLEXIÓN 3", "CIERRE"], ENDSUB=' <span class="mu" style="font-weight:700">· un laboratorio de TITÁN HOLDING</span>'),
}
CSS = open(f"{SCR}/tools/s11.css").read(); BODY = open(f"{SCR}/tools/s11_body.html").read(); JS = open(f"{SCR}/tools/s11.js").read()

def envelope(wav, dur):   # envolvente de la voz a 30 fps (0–1), con ataque rápido y caída suave
    x, sr = sf.read(wav, always_2d=True); x = x.mean(1); hop = sr // 30; n = int(dur * 30) + 1
    r = np.array([np.sqrt(np.mean(x[i * hop:(i + 1) * hop] ** 2)) if i * hop < len(x) else 0 for i in range(n)])
    r = np.clip(r / (np.percentile(r[r > 1e-4], 90) + 1e-9), 0, 1.3)
    e = np.zeros(n); a = 0
    for i, v in enumerate(r): a = v if v > a else a * 0.72; e[i] = a
    e = np.clip((e - 0.06) / 0.8, 0, 1) ** 0.8
    return [round(float(v), 3) for v in e]

for V in ["tiktok", "shorts"]:
    st = json.load(open(f"{TTS}/{V}_times.json")); T = {n: [s, round(s + d, 3)] for n, s, d in st}
    DUR = round(st[-1][1] + st[-1][2] + 3.0, 1)
    d = f"{SCR}/s11-{V}"
    for sub in ["img", "avatar", "audio"]: os.makedirs(f"{d}/assets/{sub}", exist_ok=True)
    for sub in ["fonts", "vendor"]: shutil.copytree(f"{SCR}/nas030-tiktok/assets/{sub}", f"{d}/assets/{sub}", dirs_exist_ok=True)
    for f in ["logo.png"]: shutil.copy(f"{SCR}/nas030-tiktok/assets/img/{f}", f"{d}/assets/img/")
    for k, f in list(POSES.items()) + list(OVER.items()): shutil.copy(f"{AV}/{f}.webp", f"{d}/assets/avatar/{k}.webp")
    for k in GLOW: shutil.copy(f"{SCR}/s10/glow/{k}.webp", f"{d}/assets/avatar/gl_{k}.webp")
    shutil.copy(f"{SCR}/nas030-tiktok/hyperframes.json", d)
    json.dump({"name": f"s11-{V}", "private": True, "type": "module"}, open(d + "/package.json", "w"))
    json.dump({"id": f"s11-{V}", "name": f"s11-{V}"}, open(d + "/meta.json", "w"))
    caps = []
    for n, s, du in st:
        parts = TEXTO[n].split("|"); L = [len(re.sub("<[^>]+>", "", p)) for p in parts]; t = s
        for p, l in zip(parts, L):
            dd = du * l / sum(L); caps.append([round(t, 2), round(t + dd, 2), p]); t += dd
    for k in range(len(caps) - 1): caps[k][1] = round(min(caps[k + 1][0], caps[k][1] + 0.5), 2)
    caps[-1][1] = round(caps[-1][1] + 0.6, 2)
    c = VAR[V]
    imgs = "".join(f'<img id="av_{k}" class="pose" src="assets/avatar/{k}.webp" alt="" />' for k in POSES)
    imgs += "".join(f'<img id="av_{k}" class="ov" src="assets/avatar/{k}.webp" alt="" />' for k in OVER)
    imgs += "".join(f'<img id="gl_{k}" class="gl" src="assets/avatar/gl_{k}.webp" alt="" />' for k in GLOW)
    body = (BODY.replace("{DUR}", str(DUR)).replace("{AVATAR}", imgs)
            .replace("{CAPS}", "".join(f'<div class="cp" id="cp{i}">{x[2]}</div>' for i, x in enumerate(caps)))
            .replace("{CHAPTERS}", "".join(f'<span class="ch" id="ch{i}">{x}</span>' for i, x in enumerate(c["ch"]))))
    body = body.replace("{ENDSUB}", c["ENDSUB"])
    ENV = envelope(f"{TTS}/{V}_narr.wav", DUR)
    html = f'''<!doctype html><html lang="es"><head><meta charset="UTF-8" /><meta name="viewport" content="width=1080, height=1920" />
<title>NAS100 EDGE LAB · Semana #11 · {V}</title><script src="assets/vendor/gsap.min.js"></script>
<style>{CSS}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{DUR}" data-width="1080" data-height="1920">
{body}
<audio id="vo" src="assets/audio/mix.wav" data-start="0" data-duration="{DUR}" data-track-index="30" data-volume="1"></audio>
</div>
<script>
const V = "{V}", T = {json.dumps(T)}, CAPS = {json.dumps([x[:2] for x in caps])}, DUR = {DUR};
const ENV = {json.dumps(ENV)};
{JS}
</script></body></html>'''
    open(d + "/index.html", "w").write(html)
    json.dump({"version": V, "duracion": DUR, "frases": st, "subtitulos": caps}, open(d + "/tiempos.json", "w"), ensure_ascii=False, indent=1)
    print(V, DUR, len(caps), "subtítulos")
