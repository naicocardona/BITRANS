# Capas de brillo de ojos del Explorador: una por pose, alineada al mismo lienzo (640×640)
# Uso: eye_glow.py OUT_DIR nombre=ruta.webp ...
import sys, cv2, numpy as np, json
O = sys.argv[1]; info = {}
for arg in sys.argv[2:]:
    k, p = arg.split("=", 1)
    im = cv2.imread(p, cv2.IMREAD_UNCHANGED); h, w = im.shape[:2]
    lum = im[:, :, :3].astype(int).mean(2)
    m = ((lum > 190) & (im[:, :, 3] > 200)).astype(np.uint8); m[int(h * .6):] = 0; m[:int(h * .3)] = 0
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    c = [i for i in range(1, n) if 15 < st[i, 4] and st[i, 2] <= 45 and st[i, 3] <= 80 and 170 < cen[i][0] < 395]
    c = sorted(c, key=lambda i: -st[i, 4])[:2]
    eye = np.isin(lab, c).astype(np.uint8) * 255
    core = cv2.GaussianBlur(cv2.dilate(eye, np.ones((5, 5), np.uint8)), (0, 0), 3)
    halo = cv2.GaussianBlur(cv2.dilate(eye, np.ones((9, 9), np.uint8)), (0, 0), 14)
    a = np.clip(core.astype(float) * 1.0 + halo.astype(float) * 1.6, 0, 255)
    wt = (core.astype(float) / 255.0)[..., None]
    col = wt * np.array([255, 255, 255]) + (1 - wt) * np.array([253, 181, 196])   # BGR: blanco → violeta #C4B5FD
    out = np.dstack([col, a]).astype(np.uint8)
    cv2.imwrite(f"{O}/{k}.webp", out, [cv2.IMWRITE_WEBP_QUALITY, 100])
    info[k] = [list(map(float, cen[i].round(1))) for i in c]
    print(k, info[k])
json.dump(info, open(f"{O}/ojos.json", "w"), indent=1)
