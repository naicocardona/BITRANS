# Música original distinta por versión (más calmada: semana sin operaciones) + efectos suaves + voz con ducking
import json, subprocess
S = "/tmp/claude-0/-home-user-BITRANS/e6df0451-e894-56da-93e1-0311b18c22a2/scratchpad"
for v, var, lufs in [("tiktok", "sem11t", -16), ("shorts", "sem11s", -14)]:
    d = json.load(open(f"{S}/s11-{v}/tiempos.json")); T = {n: [s, s + du] for n, s, du in d["frases"]}; DUR = d["duracion"]
    TK = v == "tiktok"; Sx = lambda n: T[n][0]
    keys = ["c1", "r1a", "r2a", "r3a", "e1"] if TK else ["s3", "s4", "s5", "s7", "e1"]
    ev = [[T["a1"][1] + 0.05, "ping"]] + [[Sx(k) - 0.3, "whoosh"] for k in keys] + [[(Sx("r1b") + 0.2) if TK else Sx("s4") + 2.3, "stamp"]]
    o = f"{S}/s11-{v}/assets/audio"
    subprocess.run(["python3", f"{S}/tools/bed_music.py", f"{o}/bed.wav", str(DUR), var], check=True, capture_output=True)
    subprocess.run(["python3", f"{S}/tools/sfx_mix.py", f"{o}/bed.wav", f"{o}/bedfx.wav", str(DUR), json.dumps(ev)], check=True, capture_output=True)
    fc = (f"[0]aresample=48000,volume=0.28,afade=t=out:st={DUR-2.0}:d=2.0[m];[1]aresample=48000,aformat=channel_layouts=stereo,apad=whole_dur={DUR},asplit[v][sc];"
          f"[m][sc]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=350[md];[md][v]amix=inputs=2:normalize=0:duration=longest,atrim=0:{DUR},loudnorm=I={lufs}:TP=-1.5:LRA=11")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", f"{o}/bedfx.wav", "-i", f"{S}/s11/tts/{v}_narr.wav", "-filter_complex", fc, "-ar", "48000", f"{o}/mix.wav"], check=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", f"{o}/mix.wav", "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
    print(v, DUR, [l.strip() for l in r.split("Summary")[1].splitlines() if "I:" in l][0])
