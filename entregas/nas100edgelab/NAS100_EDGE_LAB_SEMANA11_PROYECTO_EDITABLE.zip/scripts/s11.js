const tl = gsap.timeline({ paused: true });
const EZ = "power3.out", IO = "power2.inOut", S = n => T[n][0], F = n => T[n][1];
const TK = V === "tiktok";
function inn(sel, t, o) { o = o || {}; tl.fromTo(sel, { opacity: 0, y: o.y === undefined ? 22 : o.y }, { opacity: 1, y: 0, duration: o.d || 0.4, ease: EZ, stagger: o.st || 0, immediateRender: false }, t); }
function out(sel, t, d) { tl.to(sel, { opacity: 0, duration: d || 0.25, ease: "power2.in" }, t); }
function stamp(sel, t) { tl.fromTo(sel, { opacity: 0, scale: 1.7 }, { opacity: 1, scale: 1, duration: 0.22, ease: "power4.in", immediateRender: false }, t); }
function chapter(i, t) { document.querySelectorAll(".ch").forEach((c, k) => tl.to(c, { opacity: k === i ? 1 : 0, duration: 0.25 }, t)); }
function count(sel, a, b, t, d, fmt) { const o = { v: a }; tl.to(o, { v: b, duration: d, ease: "power2.out", onUpdate: () => { document.querySelector(sel).textContent = fmt(Math.round(o.v)); } }, t); }
function bar(sel, t, d) { tl.fromTo(sel, { scaleX: 0 }, { scaleX: 1, duration: d || 0.6, ease: EZ, immediateRender: true }, t); }
// cámara sobre la captura (coordenadas de la imagen 622×1038)
let VH = 470;
function camV(px, py, s, h) { return { x: 450 - px * s, y: (h || VH) / 2 - py * s, scale: s }; }
function cam(px, py, s, t, d, h) { tl.to("#cv .cam", Object.assign({ duration: d, ease: IO }, camV(px, py, s, h)), t); }
// ===== avatar (Explorador) =====
const POSES = Array.from(document.querySelectorAll(".pose")).map(e => e.id.slice(3));
const SCHED = [], BL = []; let ZP = 1;
function pose0(n, t, d) {
  tl.set("#av_" + n, { zIndex: ++ZP }, t);
  tl.fromTo("#av_" + n, { opacity: 0 }, { opacity: 1, duration: d, ease: "power1.out", immediateRender: false }, t);
  POSES.forEach(p => { if (p !== n) tl.set("#av_" + p, { opacity: 0 }, t + d); });
  SCHED.push([t, n]);
}
function pose(n, t) {
  const via = { senala: ["senala_t1", "senala_t2"], pensativo: ["piensa_t1"], satisfecho: ["tp_t1", "tp_t2"] }[n];
  if (via) { via.forEach((m, i) => pose0(m, t + i * 0.2, 0.08)); t += via.length * 0.2; }
  pose0(n, t, 0.1);
  tl.fromTo("#avIn", { y: 0 }, { y: -10, duration: 0.12, yoyo: true, repeat: 1, ease: "power1.out", immediateRender: false }, t);
}
tl.set("#av_neutral", { opacity: 1 }, 0); SCHED.push([0, "neutral"]);
tl.fromTo("#av", { y: 420 }, { y: 0, duration: 0.55, ease: "back.out(1.3)", immediateRender: true }, 0.1);
tl.to("#avIn", { scaleY: 1.01, duration: 1.5, yoyo: true, repeat: Math.floor(DUR / 1.5) - 1, ease: "sine.inOut" }, 0);
function lifeLayers() {   // parpadeo y manos al hablar (capas alineadas con la pose base)
  const s = SCHED.slice().sort((a, b) => a[0] - b[0]);
  const on = (id, a, b, f) => { tl.set("#av_" + id, { zIndex: 9000 }, a); tl.to("#av_" + id, { opacity: 1, duration: f || 0.04 }, a); tl.to("#av_" + id, { opacity: 0, duration: f || 0.04 }, b); if (id.endsWith("_c")) BL.push([a, b + 0.04]); };
  s.forEach(([t0, n], i) => {
    const t1 = i + 1 < s.length ? s[i + 1][0] : DUR;
    if (["senala", "pensativo", "satisfecho"].includes(n)) for (let t = t0 + 1.0; t < t1 - 0.4; t += 3.3) on(n + "_c", t, t + 0.13);
    if (n === "explica") {
      let c = 0;
      for (let t = t0 + 0.4; t < t1 - 0.6; t += 1.6, c++) {
        if (c % 2 === 0) on("explica_c", t + 0.05, t + 0.18);
        if (t + 0.8 < t1 - 0.2) on(c % 2 ? "habla_3" : "habla_2", t + 0.4, t + 0.8, 0.06);
      }
    }
  });
}
// ojos que se iluminan con la voz: envolvente a 30 fps sobre la pose activa
function eyeGlow() {
  const s = SCHED.slice().sort((a, b) => a[0] - b[0]);
  const G = {}; document.querySelectorAll(".gl").forEach(e => { G[e.id.slice(3)] = e; });
  const o = { p: 0 };
  tl.to(o, { p: 1, duration: DUR, ease: "none", onUpdate: () => {
    const t = tl.time(); let n = "neutral";
    for (const [t0, m] of s) { if (t0 <= t) n = m; else break; }
    let v = ENV[Math.min(ENV.length - 1, Math.max(0, Math.round(t * 30)))] || 0;
    for (const [a, b] of BL) if (t >= a && t <= b) { v *= 0.2; break; }
    for (const k in G) G[k].style.opacity = k === n ? v.toFixed(3) : "0";
  } }, 0);
}
// ===== estado inicial y barra de progreso =====
gsap.set("#ch0", { opacity: 1 });
gsap.set("#wx", { scaleX: 0, rotation: -8 }); gsap.set("#tlf", { opacity: 0 });
tl.fromTo("#pb", { scaleX: 0 }, { scaleX: 1, duration: DUR, ease: "none", immediateRender: false }, 0);
CAPS.forEach(([a, b], i) => { tl.fromTo("#cp" + i, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.14, ease: EZ, immediateRender: false }, a); tl.to("#cp" + i, { opacity: 0, duration: 0.1 }, b - 0.1); });
function scene(id, t) { inn(id, t - 0.15, { y: 30 }); }
// ===== 1 · gancho: ENTRADA / TAKE PROFIT / STOP LOSS se apagan y queda «0 TRADES» =====
const A1 = S("a1"), A1d = F("a1") - A1;
tl.fromTo("#gw", { scale: 1.07, y: 10 }, { scale: 1, y: 0, duration: F("a2") + 0.6, ease: "sine.out", immediateRender: true }, 0);
[["#w1", 0.08], ["#w2", 0.42], ["#w3", 0.72]].forEach(([w, f], i) => {
  const t = i === 0 ? 0.05 : A1 + A1d * f;
  tl.fromTo(w, { opacity: 0, x: -40 }, { opacity: 1, x: 0, duration: 0.35, ease: EZ, immediateRender: false }, t);
  tl.to(w + " i", { scaleX: 1, duration: 0.3, ease: "power2.inOut" }, A1 + A1d * f + 0.45);
  tl.to(w, { opacity: 0.16, duration: 0.4 }, A1 + A1d * f + 0.7);
});
tl.fromTo("#zc", { opacity: 0, scale: 0.86 }, { opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.5)", immediateRender: false }, F("a1") + 0.05);
tl.fromTo("#zc", { boxShadow: "0 0 70px rgba(167,121,242,.25)" }, { boxShadow: "0 0 110px rgba(167,121,242,.55)", duration: 0.5, yoyo: true, repeat: 1, immediateRender: false }, S("a2") + 1.4);
pose("explica", A1 + 0.2);
// ===== 2 · contexto =====
const C0 = TK ? S("c1") : S("s3");
chapter(1, C0 - 0.2);
out("#gw", C0 - 0.35);
scene("#sCx", C0); pose("explica", C0 + 0.1);
if (TK) { inn("#cx1", C0); inn("#cx2", S("c2") + 0.2); inn("#cx3", S("c3") + 1.0); }
else { inn("#cx1", C0); inn("#cx2", C0 + 1.6); }
// ===== 3 · reflexión 1: sin nueva evidencia =====
const R1 = TK ? S("r1a") : S("s4");
chapter(2, R1 - 0.2);
out("#sCx", R1 - 0.35);
scene("#sR1", R1); pose("explica", R1);
tl.set("#scan", { opacity: 1 }, R1 + 0.5);
tl.fromTo("#scan", { y: 0 }, { y: 140, duration: 0.9, ease: "power1.inOut", yoyo: true, repeat: 1, immediateRender: false }, R1 + 0.5);
tl.to("#scan", { opacity: 0, duration: 0.3 }, R1 + 2.3);
stamp("#lgStamp", TK ? S("r1b") + 0.2 : R1 + 2.3);
inn("#r1t", TK ? S("r1c") + 0.2 : R1 + 3.0);
// ===== 4 · reflexión 2: win rate N/A =====
const R2 = TK ? S("r2a") : S("s5"), R2b = TK ? S("r2b") : S("s6");
chapter(3, R2 - 0.2);
out("#sR1", R2 - 0.35);
scene("#sR2", R2);
inn("#wr1", R2 + 0.4, { y: 12 }); inn("#wr2", R2 + 1.4, { y: 12 });
pose("senala", R2 + 1.2);
tl.to("#wx", { scaleX: 1, duration: 0.3, ease: "power2.inOut" }, R2 + (TK ? 2.5 : 2.4));
tl.to("#wz", { opacity: 0, duration: 0.25 }, R2b + 0.6);
tl.fromTo("#wn", { opacity: 0, scale: 0.7 }, { opacity: 1, scale: 1, duration: 0.35, ease: "back.out(1.8)", immediateRender: false }, R2b + 0.7);
inn("#wr3", TK ? S("r2c") + 3.6 : R2b + 1.4);
inn("#r2t", TK ? S("r2c") + 0.4 : R2b + 1.0);
pose0("neutral", TK ? S("r2c") + 1.2 : R2b + 1.6, 0.12);
// ===== 5 · reflexión 3: la pausa en el historial =====
const R3 = TK ? S("r3a") : S("s7");
chapter(4, R3 - 0.2);
out("#sR2", R3 - 0.35);
scene("#sR3", R3); pose("pensativo", R3);
tl.fromTo("#tln", { scaleX: 0 }, { scaleX: 1, duration: 1.1, ease: "power2.out", immediateRender: true }, R3 + 0.3);
tl.to(".tk", { opacity: 1, duration: 0.2, stagger: 0.16 }, R3 + 0.35);
tl.fromTo("#tlf", { opacity: 0 }, { opacity: 1, duration: 0.4, immediateRender: false }, R3 + 1.5);
tl.fromTo("#nd", { opacity: 0, scale: 0.3 }, { opacity: 1, scale: 1, duration: 0.4, ease: "back.out(2)", immediateRender: false }, R3 + 1.45);
inn(["#ndT", "#ndB"], R3 + 1.7, { y: 10 });
inn("#r3t", TK ? S("r3b") + 0.6 : R3 + 3.2);
pose("explica", TK ? S("r3b") : R3 + 2.6);
// ===== 6 · cierre =====
const E0 = S("e1"), EL = TK ? S("e2") : S("s8"), EF = TK ? F("e2") : F("s8");
chapter(5, E0 - 0.2);
out("#sR3", E0 - 0.35);
tl.set("#sEnd", { opacity: 1 }, E0 - 0.15);
tl.fromTo("#sEnd .H span", { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.45, stagger: 0.18, ease: EZ, immediateRender: false }, E0 - 0.15);
inn("#disc", E0 + 0.4, { y: 0 });
pose("explica", E0);
inn("#eL", EL + 0.6);
inn("#eC", EL + (TK ? 2.2 : 1.4));
pose0("neutral", EF + 0.1, 0.1);
pose0("gira_1", EF + 0.6, 0.06); pose0("gira_2", EF + 0.75, 0.06); pose0("gira_3", EF + 0.9, 0.06);
tl.to("#av", { y: 460, duration: 0.6, ease: "power2.in" }, EF + 1.15);
lifeLayers();
eyeGlow();
tl.to({}, { duration: 0.01 }, DUR - 0.01);
window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl;
