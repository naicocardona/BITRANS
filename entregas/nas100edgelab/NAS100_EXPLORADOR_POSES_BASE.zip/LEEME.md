# Poses base del Explorador · para los 20 fotogramas V3

Son las 6 poses base: neutral, pensativo, explica (explicando), senala (señalando), satisfecho y preocupado.

## Contenido
- `lamina_original_1536x1024.png`: la lámina original con fondo transparente. Es el archivo de mayor resolución que existe de estas poses; no hay una versión más grande.
- `1_originales_exactos/`: las 6 poses recortadas de esa lámina **sin cambiar ni un píxel** (ni escala ni textura), separadas por su transparencia. Cada una mide entre 439 y 601 px de ancho y entre 470 y 494 px de alto.
- `2_lienzo_1024/`: las mismas 6 poses en un lienzo transparente de 1024 × 1024, igual al de la biblioteca:
  - Las 6 están ampliadas por el mismo factor (× 1,6, Lanczos), así que conservan su tamaño relativo.
  - La base del personaje queda en y = 1000 y la capucha centrada en x = 512. Excepción: «senala», que va desplazada a la izquierda para que el brazo no se salga del lienzo.
  - `posiciones.json` guarda la ubicación exacta de cada pose.

## Cómo usarlas
- **Bases para los 20 fotogramas:** usa `2_lienzo_1024/`. Cada fotograma nuevo debe tener exactamente el mismo lienzo y la misma posición que su pose base.
- **Para comprobar que nada se alteró:** usa `1_originales_exactos/`. La ampliación de `2_lienzo_1024/` suaviza un poco la textura respecto al original, porque el material de partida mide unos 500 px.
- **Zonas inmóviles:** consérvalas con máscaras y composición sobre la pose base, como propones. Así lo que no se mueve calza píxel por píxel.
- Para `avatar_pulgar`, `avatar_nuca`, `avatar_espalda`, `avatar_tres_cuartos` y `ojos_cerrados`, usa los archivos de 1024 × 1024 que ya tienes en `NAS100_EXPLORADOR/`.
