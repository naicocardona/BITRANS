# Proyecto editable · TITÁN HOLDING «Internet también viaja bajo el mar»

- `mar-shorts/`, `mar-tiktok/`, `mar-cover/`: composiciones HyperFrames (HTML + GSAP) con sus recursos (`assets/`): fuente, logo oficial y avatar TITÁN.
- `fuentes/`: generador (`build_mar.py`), animación (`mar.js`), estilos (`mar.css`), mundo ilustrado (`mar_world.svg`) y escenas (`mar_body.html`).
- Para sincronizar con su voz: cada composición trae `tiempos.json`. Con la grabación se miden los tiempos reales de cada frase, se guardan en `voz_mar/<version>_P.json` y se vuelve a generar; todas las escenas se reubican solas.
- Render: `npx hyperframes@0.8.134 render --fps 30 -o video.mp4` dentro de cada carpeta.
