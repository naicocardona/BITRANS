# TITÁN HOLDING · «Internet también viaja bajo el mar» · Shorts y TikTok (sin audio, con avatar TITÁN)
# Uso: build_mar.py → scratchpad/mar-shorts y scratchpad/mar-tiktok. Tiempos por frase en P (orientativos hasta tener la voz).
import os, json, shutil
SCR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
GUION = {
 "shorts": [
  "Internet también viaja bajo el mar.",
  "Tu conexión empieza cerca de ti, pero cuando los datos cruzan océanos pueden recorrer cables submarinos que conectan redes entre continentes.",
  "La fibra óptica lleva información entre costas. Y esa conexión necesita mucho más que un cable: hay que fabricarla, instalarla, operarla y repararla.",
  "Ahí aparecen negocios que casi nunca vemos cuando abrimos una aplicación.",
  "Investigar inversiones también es descubrir esas actividades y entender cómo funcionan.",
  "Pero ser parte de una infraestructura necesaria no garantiza una buena inversión.",
  "¿Qué otra infraestructura usamos todos los días sin pensar en ella?",
 ],
 "tiktok": [
  "Internet también viaja bajo el mar.",
  "Abres una aplicación y todo parece ocurrir en una pantalla. Pero cuando los datos tienen que cruzar un océano, pueden recorrer cables submarinos que conectan redes entre continentes.",
  "Según la Unión Internacional de Telecomunicaciones, por estos cables pasa más del noventa y nueve por ciento del intercambio internacional de datos.",
  "Internacional: eso no significa que cada mensaje que envías tenga que cruzar el mar.",
  "Lo interesante es todo lo que hace posible esa conexión. Hay que fabricar los cables, instalarlos, operar las redes y mantenerlas.",
  "Y si un cable sufre daños, repararlo también requiere recursos y trabajo especializado.",
  "Desde las inversiones, esto abre preguntas: ¿quién participa en cada actividad?, ¿cómo obtiene ingresos?, ¿qué costos enfrenta y qué podría salir mal?",
  "Descubrir una industria importante es el inicio del análisis, no una garantía de ganancias.",
  "La próxima vez que pienses en internet, imagina también lo que hay bajo el agua.",
  "¿Qué otra infraestructura damos por sentada?",
 ],
}
RATE, PAUSE = 2.5, 0.5
def tiempos(lines):
    t, out = 0.2, []
    for s in lines:
        n = len(s.split()); d = n / RATE
        out.append([round(t, 2), round(t + d, 2), n]); t += d + PAUSE
    return out

COMMON = '''
  <div id="hQ" class="H"><span class="ln">Internet también</span><span class="ln oro">pasa por aquí.</span></div>
  <div id="hA" class="H fx"><span class="ln">De tu pantalla…</span></div>
  <div id="hB" class="H fx"><span class="ln oro">…al fondo del mar</span></div>
  <div id="hC" class="H fx" style="font-size:64px"><span class="ln">Conectar también</span><span class="ln oro">requiere</span><span class="ln oro">infraestructura</span></div>
  <div id="hD" class="H fx" style="font-size:44px;letter-spacing:.02em"><span class="ln">Fabricar · Instalar</span><span class="ln oro">Operar · {REP}</span></div>
  <div id="hZ" class="H fx" style="font-size:56px"><span class="ln">¿Qué otra</span><span class="ln">infraestructura</span><span class="ln oro">damos por sentada?</span></div>
'''
TEXTS = {
 "shorts": COMMON.replace("{REP}", "Reparar") + '''
  <div id="hE" class="H fx" style="font-size:64px"><span class="ln">Negocios que</span><span class="ln oro">casi nunca vemos</span></div>
  <div id="hF" class="H fx" style="font-size:60px"><span class="ln">Investigar también</span><span class="ln oro">es descubrir</span><span class="ln">cómo funcionan</span></div>
 ''',
 "tiktok": COMMON.replace("{REP}", "Mantener") + '''
  <div id="hI" class="H fx" style="font-size:62px"><span class="ln">Internacional</span><span class="ln oro">≠ cada mensaje</span></div>
  <div id="hR" class="H fx" style="font-size:62px"><span class="ln">Si se daña,</span><span class="ln oro">hay que repararlo</span></div>
  <div id="hQ1" class="H fx" style="font-size:60px"><span class="k">Desde las inversiones</span><span class="ln">Preguntas</span><span class="ln oro">para investigar</span></div>
  <div id="hM" class="H fx" style="font-size:64px"><span class="ln">Imagina lo que hay</span><span class="ln oro">bajo el agua</span></div>
 ''',
}
NEQ = '<div id="neq" class="neq fx"><div class="ln" style="font-size:96px">Necesario</div><div class="ln" style="font-size:150px;color:#C4B5FD;line-height:1">≠</div><div class="ln" style="font-size:80px;color:#E2B34E;line-height:1.02">Ganancia<br/>garantizada</div></div>'
EXTRA = {
 "shorts": NEQ,
 "tiktok": NEQ + '''
  <div id="neqS" class="fx" style="position:absolute;left:90px;top:1000px;width:900px;text-align:center;font-size:34px;font-weight:800;color:rgba(246,244,239,.85)">El inicio del análisis, no una garantía</div>
  <div id="data" class="card fx" style="top:540px">
    <div style="font-size:34px;font-weight:900;letter-spacing:.12em">MÁS DEL</div>
    <div class="big" id="pct" style="margin-top:18px">0 %</div>
    <div style="font-size:40px;font-weight:850;line-height:1.15;margin-top:14px">del intercambio <span class="lav">internacional</span> de datos pasa por <span class="oro">cables submarinos</span></div>
    <div style="font-size:26px;font-weight:700;color:rgba(246,244,239,.7);margin-top:18px">Fuente: UIT</div>
  </div>
  <div class="qc fx" id="q1" style="top:560px"><b>01</b>¿Quién participa?</div>
  <div class="qc fx" id="q2" style="top:690px"><b>02</b>¿Cómo obtiene ingresos?</div>
  <div class="qc fx" id="q3" style="top:820px"><b>03</b>¿Qué costos enfrenta?</div>
  <div class="qc fx" id="q4" style="top:950px"><b>04</b>¿Qué podría salir mal?</div>
 ''',
}
POSES = ["titan_neutral", "titan_rostro_sorpresa", "titan_explicando", "titan_senala_derecha", "titan_idea", "titan_alto", "titan_duda",
         "titan_pensativo", "titan_niega", "titan_t_senala", "titan_t_pensativo", "titan_asiente_v2_1", "titan_asiente_v2_2", "titan_asiente_v2_3"]
OVER = ["titan_neutral_ojos_entrecerrados", "titan_neutral_ojos_cerrados", "titan_explicando_ojos_cerrados", "titan_pensativo_ojos_cerrados", "titan_explica_v2_2", "titan_explica_v2_3"]
WORLD = open(f"{SCR}/tools/mar_world.svg").read()
BODY = open(f"{SCR}/tools/mar_body.html").read()
CSS = open(f"{SCR}/tools/mar.css").read()
JS = open(f"{SCR}/tools/mar.js").read()
for V in ["shorts", "tiktok"]:
    vp = f"{SCR}/voz_mar/{V}_P.json"
    P = json.load(open(vp)) if os.path.exists(vp) else tiempos(GUION[V])
    DUR = round(P[-1][1] + 2.6, 1)
    d = f"{SCR}/mar-{V}"; os.makedirs(d + "/assets/avatar", exist_ok=True)
    for sub in ["fonts", "vendor", "brand"]: shutil.copytree(f"{SCR}/titan-caja/assets/{sub}", f"{d}/assets/{sub}", dirs_exist_ok=True)
    for p in POSES + OVER: shutil.copy(f"{SCR}/caja2_assets/avatar/{p}.webp", d + "/assets/avatar/")
    shutil.copy(f"{SCR}/caja2_assets/avatar/oficina.jpg", d + "/assets/avatar/")
    shutil.copy(f"{SCR}/titan-caja/hyperframes.json", d)
    json.dump({"name": f"mar-{V}", "private": True, "type": "module"}, open(d + "/package.json", "w"))
    json.dump({"id": f"mar-{V}", "name": f"mar-{V}"}, open(d + "/meta.json", "w"))
    imgs = "".join(f'<img id="{p}" class="pose" src="assets/avatar/{p}.webp" alt="" />' for p in POSES)
    imgs += "".join(f'<img id="{p}" class="ov" src="assets/avatar/{p}.webp" alt="" />' for p in OVER)
    body = BODY.replace("{DUR}", str(DUR)).replace("{WORLD}", WORLD).replace("{TEXTS}", TEXTS[V]).replace("{EXTRA}", EXTRA[V]).replace("{AVATAR}", imgs)
    html = f'''<!doctype html><html lang="es"><head><meta charset="UTF-8" /><meta name="viewport" content="width=1080, height=1920" />
<title>TITÁN Holding · Internet bajo el mar · {V}</title><script src="assets/vendor/gsap.min.js"></script>
<style>{CSS}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{DUR}" data-width="1080" data-height="1920">
{body}
</div>
<script>
const V = "{V}", P = {json.dumps(P)}, DUR = {DUR};
{JS}
</script></body></html>'''
    open(d + "/index.html", "w").write(html)
    json.dump({"version": V, "duracion": DUR, "frases": [[p[0], p[1], GUION[V][i]] for i, p in enumerate(P)]}, open(d + "/tiempos.json", "w"), ensure_ascii=False, indent=1)
    print(V, DUR)
