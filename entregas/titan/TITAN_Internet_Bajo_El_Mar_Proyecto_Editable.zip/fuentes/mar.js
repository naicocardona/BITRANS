// ===== utilidades =====
const W = (p, k) => {   // instante de la palabra k de la frase p (por tramos reales de la voz si existen)
  const subs = P[p][3];
  if (!subs) return P[p][0] + (P[p][1] - P[p][0]) * k / P[p][2];
  let acc = 0;
  for (const [s, e, m] of subs) { if (k <= acc + m) return s + (e - s) * (k - acc) / m; acc += m; }
  return P[p][1];
};
const S0 = p => P[p][0], S1 = p => P[p][1];
const tl = gsap.timeline({ paused: true });
const E3 = "power3.out", IO = "power2.inOut", TK = V === "tiktok";
const SY = 960;
function camV(cx, cy, s) { return { x: 540 - cx * s, y: SY - cy * s, scale: s }; }
function cam(cx, cy, s, t, d, ease) { tl.to("#world", Object.assign({ duration: d, ease: ease || IO }, camV(cx, cy, s)), t); }
function inn(sel, t, o) { o = o || {}; tl.fromTo(sel, { opacity: 0, y: o.y === undefined ? 24 : o.y }, { opacity: 1, y: 0, duration: o.d || 0.45, ease: E3, stagger: o.st || 0, immediateRender: false }, t); }
function out(sel, t, d) { tl.to(sel, { opacity: 0, duration: d || 0.3, ease: "power2.in" }, t); }
function head(id, a, b) {
  tl.set("#" + id, { opacity: 1 }, a);
  tl.fromTo(`#${id} .ln, #${id} .k`, { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.09, ease: E3, immediateRender: false }, a);
  if (b) tl.to("#" + id, { opacity: 0, duration: 0.25, ease: "power2.in" }, b - 0.25);
}
// ===== avatar TITÁN (recuadro abajo a la izquierda) =====
const POSES = Array.from(document.querySelectorAll(".pose")).map(e => e.id);
const SCHED = []; let ZP = 1;
function pose0(n, t, d) {
  tl.set("#" + n, { zIndex: ++ZP }, t);
  tl.fromTo("#" + n, { opacity: 0 }, { opacity: 1, duration: d, ease: "power1.out", immediateRender: false }, t);
  POSES.forEach(p => { if (p !== n) tl.set("#" + p, { opacity: 0 }, t + d); });
  SCHED.push([t, n]);
}
function pose(n, t) {
  const prev = SCHED.length ? SCHED[SCHED.length - 1][1] : null;
  if (n === "titan_senala_derecha" || n === "titan_pensativo") {
    const mid = n === "titan_senala_derecha" ? "titan_t_senala" : "titan_t_pensativo";
    if (prev !== "titan_neutral") { pose0("titan_neutral", t, 0.08); t += 0.12; }
    pose0(mid, t, 0.08); pose0(n, t + 0.2, 0.08);
  } else pose0(n, t, 0.12);
  tl.fromTo("#avIn", { scale: 1 }, { scale: 1.02, duration: 0.18, yoyo: true, repeat: 1, ease: "power1.out", immediateRender: false }, t);
}
function nod(t) { [["titan_asiente_v2_1", 0], ["titan_asiente_v2_2", 0.16], ["titan_asiente_v2_3", 0.32], ["titan_asiente_v2_2", 0.48], ["titan_asiente_v2_1", 0.64], ["titan_neutral", 0.82]].forEach(([n, dt]) => pose0(n, t + dt, 0.08)); }
function avShow(t, n) {
  POSES.forEach(p => tl.set("#" + p, { opacity: p === n ? 1 : 0 }, t)); SCHED.push([t, n]);
  tl.fromTo("#av", { opacity: 0, y: 120, scale: 0.92 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "back.out(1.4)", immediateRender: false }, t);
}
function avHide(t) { tl.to("#av", { opacity: 0, y: 120, duration: 0.35, ease: "power2.in" }, t); SCHED.push([t, null]); }
tl.to("#avIn", { scaleY: 1.008, duration: 1.7, yoyo: true, repeat: Math.floor(DUR / 1.7), ease: "sine.inOut" }, 0);
function lifeLayers() {
  const s = SCHED.slice().sort((a, b) => a[0] - b[0]);
  const on = (id, a, b, f) => { tl.set("#" + id, { zIndex: 9000 }, a); tl.to("#" + id, { opacity: 1, duration: f || 0.04 }, a); tl.to("#" + id, { opacity: 0, duration: f || 0.04 }, b); };
  s.forEach(([t0, n], i) => {
    const t1 = i + 1 < s.length ? s[i + 1][0] : DUR;
    if (n === "titan_neutral" || n === "titan_pensativo") for (let t = t0 + 1.1; t < t1 - 0.5; t += 3.4) {
      if (n === "titan_neutral") { on("titan_neutral_ojos_entrecerrados", t, t + 0.07); on("titan_neutral_ojos_cerrados", t + 0.07, t + 0.17); on("titan_neutral_ojos_entrecerrados", t + 0.17, t + 0.24); }
      else on("titan_pensativo_ojos_cerrados", t, t + 0.14);
    }
    if (n === "titan_explicando") { let c = 0;
      for (let t = t0 + 0.5; t < t1 - 0.7; t += 2.4, c++) {
        if (c % 2 === 0) on("titan_explicando_ojos_cerrados", t + 0.15, t + 0.29);
        if (t + 1.2 < t1 - 0.3) on("titan_explica_v2_2", t + 0.6, t + 1.2, 0.08);
        if (t + 2.4 < t1 - 0.3) on("titan_explica_v2_3", t + 1.8, t + 2.4, 0.08);
      } }
  });
}
// ===== entorno vivo (discreto) =====
tl.fromTo("#waves", { x: 0 }, { x: -160, duration: 2.6, ease: "none", repeat: Math.floor(DUR / 2.6), immediateRender: false }, 0);
tl.fromTo("#motes", { y: 0 }, { y: -60, duration: 6, ease: "sine.inOut", yoyo: true, repeat: Math.floor(DUR / 6), immediateRender: false }, 0);
tl.to("#ship", { y: -6, duration: 1.6, yoyo: true, repeat: Math.floor(DUR / 1.6), ease: "sine.inOut" }, 0);
// ===== línea de datos y pulso =====
const DL = document.getElementById("dataLine"), DLL = DL.getTotalLength();
gsap.set(["#dataLine", "#dataGlow"], { strokeDasharray: DLL, strokeDashoffset: DLL });
function travel(a, b, p0, p1, follow, s) {   // el pulso avanza de p0 a p1 del recorrido; la cámara lo sigue si follow
  const o = { p: p0 };
  tl.set(["#pulse", "#pulseG"], { opacity: 1 }, a);
  tl.fromTo(o, { p: p0 }, { p: p1, duration: b - a, ease: "none", immediateRender: false, onUpdate: () => {
    const pt = DL.getPointAtLength(o.p * DLL);
    gsap.set(["#pulse", "#pulseG"], { attr: { cx: pt.x, cy: pt.y } });
    gsap.set(["#dataLine", "#dataGlow"], { strokeDashoffset: DLL * (1 - o.p) });
    if (follow) gsap.set("#world", camV(pt.x + 120, pt.y - 60, s));
  } }, a);
}
function fracAtDepth(y) { for (let f = 0; f <= 1; f += 0.002) { if (DL.getPointAtLength(f * DLL).y > y) return f; } return 1; }

// ===== estado inicial: el móvil junto a la sección del océano, cable visible desde el cuadro 0 =====
const OPEN = [1550, 1250, 0.45];
gsap.set("#world", camV(...OPEN));
gsap.set("#miniPhone", { opacity: 0 });
gsap.set("#hQ", { opacity: 1 });
tl.fromTo("#bubOut", { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1, duration: 0.3, ease: "back.out(2)", immediateRender: true }, 0.2);
tl.fromTo("#sent", { opacity: 0 }, { opacity: 1, duration: 0.2, immediateRender: true }, 0.45);
tl.to("#cableCore", { opacity: 1, duration: 0.4 }, 0.5);
travel(0.5, 1.7, 0, 0.42, false);             // la línea luminosa baja hasta el cable antes del segundo 2
tl.to(["#pulse", "#pulseG"], { opacity: 0, duration: 0.3 }, 1.8);
tl.fromTo("#cabLbl", { opacity: 0 }, { opacity: 1, duration: 0.35, immediateRender: false }, 1.35);
tl.to("#cabLbl", { opacity: 0, duration: 0.3 }, S0(1) - 0.1);
tl.to("#cabLbl", { opacity: 1, duration: 0.4 }, S0(P.length - 1) + 0.2);

// ===== recorrido: ciudad → costa → cable → otra costa =====
const J0 = S0(1), J1 = S1(1) + 0.3;
out("#hQ", J0 - 0.1);
tl.to("#phone", { scale: 0.28, x: 100, y: -10, opacity: 0, duration: 0.6, ease: IO }, J0 - 0.1);
tl.set("#miniPhone", { opacity: 1 }, J0 + 0.3);
tl.set(["#dataLine", "#dataGlow"], { strokeDashoffset: DLL }, J0);
tl.to("#tag", { opacity: 1, duration: 0.4 }, J0 + 0.6);
cam(900, 640, 1.0, J0, 0.7);
const fDive = fracAtDepth(1000);
const jT = t => J0 + 0.7 + (J1 - J0 - 0.7) * t;
travel(J0 + 0.7, J1, 0, 1, true, 0.95);
head("hA", J0 + 0.1, jT(fDive) - 0.1);
head("hB", jT(fDive), J1 + 0.4);
document.querySelectorAll(".ndB").forEach((n, i) => tl.fromTo(n, { attr: { r: 10 } }, { attr: { r: 22 }, duration: 0.3, yoyo: true, repeat: 1, immediateRender: false }, J1 - 0.6 + i * 0.12));
tl.to(["#pulse", "#pulseG"], { opacity: 0, duration: 0.3 }, J1 + 0.1);
tl.to("#tag", { opacity: 0, duration: 0.3 }, J1 + 0.2);

// escena de fondo para explicaciones: el cable en el lecho marino, atenuado
function under(t, dim) { cam(3250, 1750, 0.8, t, 1.0); tl.to("#wwrap", { opacity: dim, duration: 0.6 }, t + 0.2); }

if (!TK) {
  // 3 · fibra óptica + 4 · actividades
  under(S0(2) - 0.4, 0.35);
  tl.set("#fiber", { opacity: 1 }, S0(2)); inn("#fiber svg", S0(2), { y: 30 });
  tl.fromTo("#cores circle", { scale: 0.4, transformOrigin: "50% 50%" }, { scale: 1.15, duration: 0.6, yoyo: true, repeat: 5, ease: "sine.inOut", immediateRender: false }, S0(2) + 0.3);
  avShow(S0(2) + 0.2, "titan_explicando");
  out("#fiber", W(2, 7) - 0.2);
  head("hC", W(2, 7), W(2, 16));
  tl.set("#acts", { opacity: 1 }, W(2, 16));
  inn("#a1", W(2, 18)); inn("#a2", W(2, 19)); inn("#a3", W(2, 20)); inn("#a4", W(2, 22));
  head("hD", W(2, 16), S0(3) - 0.1);
  out("#acts", S0(3) - 0.35);
  // 5 · negocios que casi nunca vemos
  tl.set("#map", { opacity: 1 }, S0(3)); inn("#map svg", S0(3), { y: 30 });
  tl.fromTo("#arcs .arc", { strokeDasharray: 600, strokeDashoffset: 600 }, { strokeDashoffset: 0, duration: 0.7, stagger: 0.25, ease: "power2.out", immediateRender: true }, S0(3) + 0.3);
  tl.set("#tag", { left: 700, top: 1130 }, S0(3)); inn("#tag", S0(3) + 0.3, { y: 0 });
  head("hE", S0(3), S0(4));
  pose("titan_senala_derecha", S0(3) + 0.1); nod(S1(3) - 0.9);
  // 6 · investigar
  head("hF", S0(4), S0(5));
  pose("titan_idea", S0(4));
  tl.set("#mapMag", { opacity: 1, x: 290, y: 160 }, S0(4) + 0.3);
  tl.to("#mapMag", { keyframes: [{ x: 615, y: 140, duration: 0.9 }, { x: 590, y: 420, duration: 0.9 }, { x: 240, y: 240, duration: 0.9 }], ease: IO }, S0(4) + 0.8);
  out(["#map", "#tag"], S0(5) - 0.35);
  // 7 · necesario ≠ ganancia garantizada
  tl.set("#neq", { opacity: 1 }, S0(5));
  tl.fromTo("#neq .ln", { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.14, ease: E3, immediateRender: false }, S0(5));
  pose("titan_alto", S0(5)); pose("titan_duda", W(5, 7));
  avHide(S1(5) + 0.1); out("#neq", S1(5) + 0.1);
} else {
  // 3 · el dato (UIT)
  under(S0(2) - 0.4, 0.4);
  tl.set("#data", { opacity: 1 }, S0(2)); inn("#data", S0(2), { y: 30 });
  const o = { v: 0 }; tl.to(o, { v: 99, duration: 1.2, ease: "power2.out", onUpdate: () => { document.getElementById("pct").textContent = Math.round(o.v) + " %"; } }, W(2, 10));
  avShow(S0(2) + 0.2, "titan_rostro_sorpresa"); pose("titan_explicando", W(2, 12));
  out("#data", S1(2) + 0.1);
  // 4 · internacional ≠ cada mensaje
  tl.to("#wwrap", { opacity: 1, duration: 0.4 }, S0(3) - 0.3); cam(760, 640, 1.0, S0(3) - 0.3, 0.9);
  tl.to("#localArc", { opacity: 1, duration: 0.3 }, S0(3) + 0.6);
  tl.fromTo("#localArc", { strokeDashoffset: 0 }, { strokeDashoffset: -104, duration: 1.2, ease: "none", repeat: 3, immediateRender: false }, S0(3) + 0.6);
  head("hI", S0(3), S1(3) + 0.3);
  pose("titan_niega", S0(3));
  tl.to("#localArc", { opacity: 0, duration: 0.3 }, S1(3) + 0.1);
  // 5 · actividades
  under(S0(4) - 0.4, 0.3);
  head("hC", S0(4), W(4, 10));
  pose("titan_explicando", S0(4));
  tl.set("#acts", { opacity: 1 }, W(4, 10));
  inn("#a1", W(4, 12)); inn("#a2", W(4, 15)); inn("#a3", W(4, 16)); inn("#a4", W(4, 20));
  head("hD", W(4, 10), S1(4) + 0.3);
  out("#acts", S1(4) + 0.1); nod(S1(4) - 0.7);
  // 6 · daño y reparación
  tl.to("#wwrap", { opacity: 1, duration: 0.5 }, S0(5) - 0.4); cam(3300, 1430, 0.62, S0(5) - 0.4, 1.0);
  tl.to("#dmg", { opacity: 1, duration: 0.3 }, S0(5) + 0.8);
  tl.to("#dmg", { scale: 1.15, svgOrigin: "3300 1985", duration: 0.5, yoyo: true, repeat: 3, ease: "sine.inOut" }, S0(5) + 1.1);
  tl.to("#grap", { attr: { y2: 1960 }, duration: 1.8, ease: IO }, W(5, 6));
  tl.to("#dmg", { opacity: 0, duration: 0.4 }, S1(5) - 0.3);
  head("hR", S0(5), S1(5) + 0.3);
  pose("titan_pensativo", S0(5));
  // 7 · preguntas para investigar
  under(S0(6) - 0.4, 0.25);
  tl.set("#map", { opacity: 0.35 }, S0(6));
  head("hQ1", S0(6), S1(6) + 0.3);
  inn("#q1", W(6, 6)); inn("#q2", W(6, 11)); inn("#q3", W(6, 14)); inn("#q4", W(6, 17));
  pose("titan_idea", S0(6)); pose("titan_explicando", W(6, 6));
  out(["#q1", "#q2", "#q3", "#q4", "#map"], S1(6) + 0.1);
  // 8 · necesario ≠ ganancia garantizada
  tl.set("#neq", { opacity: 1 }, S0(7));
  tl.fromTo("#neq .ln", { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.14, ease: E3, immediateRender: false }, S0(7));
  inn("#neqS", W(7, 6));
  pose("titan_alto", S0(7)); pose("titan_duda", W(7, 8));
  avHide(S1(7) + 0.1); out(["#neq", "#neqS"], S1(7) + 0.1);
}
// ===== cierre: de vuelta al móvil y al cable =====
const CL = TK ? 8 : 6;
tl.to("#wwrap", { opacity: 1, duration: 0.5 }, S0(CL) - 0.5);
cam(...OPEN, S0(CL) - 0.5, 1.1);
tl.set("#miniPhone", { opacity: 0 }, S0(CL) + 0.4);
tl.to("#phone", { scale: 1, x: 0, y: 0, opacity: 1, duration: 0.6, ease: E3 }, S0(CL) + 0.2);
tl.fromTo("#cableCore", { opacity: 0.5 }, { opacity: 1, duration: 0.6, yoyo: true, repeat: 3, ease: "sine.inOut", immediateRender: false }, S0(CL) + 0.6);
if (TK) { head("hM", S0(8), S0(9)); head("hZ", S0(9), null); }
else head("hZ", S0(6), null);
const LAST = P.length - 1;
inn("#firma", S1(LAST) + 0.3, { y: 16 }); inn("#note", S1(LAST) + 0.5, { y: 10 });
lifeLayers();
tl.to({}, { duration: 0.01 }, DUR - 0.01);
window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl;
