# Proyecto editable · TITÁN HOLDING «El mundo en una caja»

- `caja2-shorts/`, `caja2-tiktok/`, `caja2-cover/`: composiciones HyperFrames (HTML + GSAP), cada una con sus recursos en `assets/`: fuente Inter, logo oficial y poses del avatar.
- `fuentes/`: el generador (`build_caja2.py`), la animación (`caja2.js`), los estilos (`caja2.css`) y las ilustraciones SVG (puerta y caja, mundo y red de negocios).
- **Para sincronizar con la voz:** cada composición tiene `tiempos.json` con el inicio y el fin de cada frase. Al recibir la grabación, se miden los tiempos reales de cada frase, se reemplazan en `P` (en `build_caja2.py`) y se vuelve a generar. Todas las escenas se reubican solas.
- **Render:** `npx hyperframes@0.8.134 render --fps 30 -o video.mp4`, ejecutado dentro de cada carpeta.
