# TITÁN HOLDING · «El mundo en una caja» · versiones Shorts y TikTok (sin audio, con avatar)
# Uso: build_caja2.py  → genera scratchpad/caja2-shorts y scratchpad/caja2-tiktok
# Los tiempos de cada frase del guion están en P (inicio, fin, palabras). Al recibir la voz real, se reemplaza P y todo se reajusta.
import os, json, shutil
SCR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

GUION = {
 "shorts": [
  "¿Cuánto mundo cabe en esta caja?",
  "Ves un paquete en tu puerta, pero su historia empezó mucho antes.",
  "Si viene del exterior, pudo pasar por una fábrica, un puerto, un barco y un almacén antes de llegar a tus manos.",
  "En cada etapa hay negocios distintos: unos fabrican, otros transportan, otros almacenan y otros reparten.",
  "Por eso, investigar inversiones también es aprender a mirar detrás de lo que compramos.",
  "Pero que una industria sea necesaria no significa que todas sus empresas sean una buena inversión. También importan sus costos, sus riesgos y el precio que pagas.",
  "¿Qué recorrido habrá hecho lo último que compraste?",
 ],
 "tiktok": [
  "¿Cuánto mundo cabe en esta caja?",
  "Parece un paquete más. Pero antes de llegar a tu puerta, pudo conectar negocios de distintos lugares del mundo.",
  "Todo empieza con un producto. Hay que fabricarlo, prepararlo y organizar su salida.",
  "Si cruza el mar, puede pasar por un puerto y viajar dentro de un contenedor. Al llegar, todavía falta llevarlo a un almacén, clasificarlo y preparar su reparto.",
  "No todos los pedidos siguen esa ruta. Es un ejemplo de algo que normalmente no vemos: detrás de una compra hay muchas actividades conectadas.",
  "Y ahí aparece una forma de investigar inversiones. Preguntarse quién fabrica, quién mueve la mercancía, quién la almacena y cómo gana dinero cada negocio.",
  "Después vienen otras preguntas: cuánto le cuesta operar, con quién compite y qué podría salir mal.",
  "Porque participar en el comercio mundial no garantiza ganar dinero. Una empresa puede tener mucho trabajo y aun así enfrentar costos altos o dificultades.",
  "La próxima vez que recibas un paquete, mira más allá de la caja.",
  "¿Qué recorrido habrá hecho tu última compra?",
 ],
}
RATE, PAUSE = 2.5, 0.5          # lectura orientativa: 2,5 palabras/s y media pausa entre frases

def tiempos(lines):
    t, out = 0.2, []
    for s in lines:
        n = len(s.split()); d = n / RATE
        out.append([round(t, 2), round(t + d, 2), n]); t += d + PAUSE
    return out

WORLD_SVG = open(os.path.join(SCR, "tools", "caja2_world.svg")).read()
DOOR_SVG = open(os.path.join(SCR, "tools", "caja2_door.svg")).read()
NET_SVG = open(os.path.join(SCR, "tools", "caja2_net.svg")).read()
JS = open(os.path.join(SCR, "tools", "caja2.js")).read()
CSS = open(os.path.join(SCR, "tools", "caja2.css")).read()

POSES = ["titan_neutral", "titan_rostro_sorpresa", "titan_explicando", "titan_senala_derecha", "titan_idea",
         "titan_alto", "titan_duda", "titan_pensativo", "titan_niega", "titan_presenta_derecha",
         "titan_t_senala", "titan_t_pensativo", "titan_asiente_v2_1", "titan_asiente_v2_2", "titan_asiente_v2_3"]
OVER = ["titan_neutral_ojos_entrecerrados", "titan_neutral_ojos_cerrados", "titan_explicando_ojos_cerrados",
        "titan_pensativo_ojos_cerrados", "titan_explica_v2_2", "titan_explica_v2_3"]   # capas sobre la pose base (parpadeo y manos)

TEXTOS = {
 "shorts": '''
  <div id="hQ" class="H"><span class="ln">¿Cuánto mundo</span><span class="ln oro">cabe aquí?</span></div>
  <div id="h2" class="H fx"><span class="ln">Su historia</span><span class="ln oro">empezó mucho antes</span></div>
  <div id="hF" class="H fx"><span class="k">Fábrica</span><span class="ln">Producción</span></div>
  <div id="hP" class="H fx"><span class="k">Puerto</span><span class="ln">Transporte</span></div>
  <div id="hB" class="H fx"><span class="k">Barco</span><span class="ln">Transporte</span></div>
  <div id="hA" class="H fx"><span class="k">Almacén</span><span class="ln">Almacenamiento</span></div>
  <div id="h4" class="H fx" style="font-size:66px"><span class="ln">Una compra.</span><span class="ln oro">Distintos negocios.</span></div>
  <div id="h5" class="H fx" style="font-size:66px"><span class="ln">Mirar detrás de</span><span class="ln oro">lo que compramos</span></div>
  <div id="hRk" class="H fx" style="font-size:40px; letter-spacing:.06em"><span class="ln lav">El matiz</span></div>
  <div id="h7" class="H fx" style="font-size:64px"><span class="ln">¿Qué recorrido</span><span class="ln">hizo tu</span><span class="ln oro">última compra?</span></div>
 ''',
 "tiktok": '''
  <div id="hQ" class="H"><span class="ln">¿Cuánto mundo</span><span class="ln oro">cabe aquí?</span></div>
  <div id="h2" class="H fx"><span class="k">Antes de llegar a tu puerta</span><span class="ln">Negocios</span><span class="ln oro">conectados</span></div>
  <div id="hF" class="H fx"><span class="k">Fábrica</span><span class="ln">Producción</span></div>
  <div id="hP" class="H fx"><span class="k">Puerto · contenedor</span><span class="ln">Transporte</span></div>
  <div id="hB" class="H fx"><span class="k">Barco</span><span class="ln">Transporte</span></div>
  <div id="hA" class="H fx"><span class="k">Almacén · clasificación</span><span class="ln">Almacenamiento</span></div>
  <div id="hR" class="H fx"><span class="k">Preparar la entrega</span><span class="ln">Reparto</span></div>
  <div id="h5a" class="H fx" style="font-size:62px"><span class="ln">No todos los pedidos</span><span class="ln oro">siguen esta ruta</span></div>
  <div id="h4" class="H fx" style="font-size:66px"><span class="ln">Una compra.</span><span class="ln oro">Distintos negocios.</span></div>
  <div id="q1" class="H fx" style="font-size:66px"><span class="k">Preguntas para investigar</span><span class="ln">¿Quién</span><span class="ln oro">fabrica?</span></div>
  <div id="q2" class="H fx" style="font-size:66px"><span class="k">Preguntas para investigar</span><span class="ln">¿Quién mueve</span><span class="ln oro">la mercancía?</span></div>
  <div id="q3" class="H fx" style="font-size:66px"><span class="k">Preguntas para investigar</span><span class="ln">¿Quién la</span><span class="ln oro">almacena?</span></div>
  <div id="q4" class="H fx" style="font-size:62px"><span class="k">Preguntas para investigar</span><span class="ln">¿Cómo gana dinero</span><span class="ln oro">cada negocio?</span></div>
  <div id="h7" class="H fx" style="font-size:66px"><span class="ln">Después,</span><span class="ln oro">otras preguntas</span></div>
  <div id="hRk" class="H fx" style="font-size:40px; letter-spacing:.06em"><span class="ln lav">El matiz</span></div>
  <div id="h9" class="H fx" style="font-size:72px"><span class="ln">Mira más allá</span><span class="ln oro">de la caja</span></div>
  <div id="h10" class="H fx" style="font-size:64px"><span class="ln">¿Qué recorrido</span><span class="ln">hizo tu</span><span class="ln oro">última compra?</span></div>
 ''',
}

EXTRA = {
 "shorts": '''
  <div id="chips" class="clip" data-start="0" data-duration="{DUR}" data-track-index="11">
    <div class="chip fx" id="cp1"><b class="ic">◆</b>Costos</div>
    <div class="chip fx" id="cp2"><b class="ic">▲</b>Riesgos</div>
    <div class="chip fx" id="cp3"><b class="ic">●</b>Precio que pagas</div>
  </div>''',
 "tiktok": '''
  <div id="steps" class="clip" data-start="0" data-duration="{DUR}" data-track-index="11">
    <div class="chip fx" id="st1">Fabricar</div><div class="chip fx" id="st2">Preparar</div><div class="chip fx" id="st3">Organizar la salida</div>
  </div>
  <div id="qc" class="clip" data-start="0" data-duration="{DUR}" data-track-index="12">
    <div class="qcard fx" id="qc1"><b>01</b><span>¿Cuánto le cuesta operar?</span></div>
    <div class="qcard fx" id="qc2"><b>02</b><span>¿Con quién compite?</span></div>
    <div class="qcard fx" id="qc3"><b>03</b><span>¿Qué podría salir mal?</span></div>
  </div>
  <div id="chips" class="clip" data-start="0" data-duration="{DUR}" data-track-index="13">
    <div class="chip fx" id="cp1"><b class="ic">◆</b>Mucho trabajo</div>
    <div class="chip fx" id="cp2"><b class="ic">▲</b>Costos altos</div>
    <div class="chip fx" id="cp3"><b class="ic">●</b>Dificultades</div>
  </div>''',
}

for V in ["shorts", "tiktok"]:
    vp = f"{SCR}/voz_caja/{V}_P.json"   # tiempos reales de la voz grabada, si existen
    P = json.load(open(vp)) if os.path.exists(vp) else tiempos(GUION[V])
    END_EXTRA = 2.6                       # firma y nota tras la última frase (sin pantalla larga)
    DUR = round(P[-1][1] + END_EXTRA, 1)
    d = f"{SCR}/caja2-{V}"; os.makedirs(d + "/assets/avatar", exist_ok=True)
    shutil.copytree(f"{SCR}/titan-caja/assets/fonts", d + "/assets/fonts", dirs_exist_ok=True)
    shutil.copytree(f"{SCR}/titan-caja/assets/vendor", d + "/assets/vendor", dirs_exist_ok=True)
    shutil.copytree(f"{SCR}/titan-caja/assets/brand", d + "/assets/brand", dirs_exist_ok=True)
    for p in POSES + OVER: shutil.copy(f"{SCR}/caja2_assets/avatar/{p}.webp", d + "/assets/avatar/")
    shutil.copy(f"{SCR}/caja2_assets/avatar/oficina.jpg", d + "/assets/avatar/")
    shutil.copy(f"{SCR}/titan-caja/hyperframes.json", d)
    json.dump({"name": f"caja2-{V}", "private": True, "type": "module"}, open(d + "/package.json", "w"))
    json.dump({"id": f"caja2-{V}", "name": f"caja2-{V}"}, open(d + "/meta.json", "w"))
    imgs = "".join(f'<img id="{p}" class="pose" src="assets/avatar/{p}.webp" alt="" />' for p in POSES)
    imgs += "".join(f'<img id="{p}" class="ov" src="assets/avatar/{p}.webp" alt="" />' for p in OVER)
    html = f'''<!doctype html>
<html lang="es"><head><meta charset="UTF-8" /><meta name="viewport" content="width=1080, height=1920" />
<title>TITÁN Holding · El mundo en una caja · {V}</title>
<script src="assets/vendor/gsap.min.js"></script>
<style>{CSS}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{DUR}" data-width="1080" data-height="1920">
  <div id="wwrap" class="clip" data-layout-allow-overflow data-start="0" data-duration="{DUR}" data-track-index="1">
    <div id="far"><svg viewBox="0 0 5400 700" width="5400" height="700">{WORLD_SVG.split("<!--FAR-->")[1]}</svg></div>
    <div id="world"><svg viewBox="0 0 5400 700" width="5400" height="700">{WORLD_SVG.split("<!--FAR-->")[2]}</svg></div>
  </div>
  <div id="net" class="clip fx" data-layout-allow-overflow data-start="0" data-duration="{DUR}" data-track-index="2">{NET_SVG}</div>
  <div id="door" class="clip" data-layout-allow-overflow data-start="0" data-duration="{DUR}" data-track-index="3">{DOOR_SVG}</div>
  <div id="rk" class="clip fx" data-start="0" data-duration="{DUR}" data-track-index="4"><span class="ln">Una industria</span><span class="ln">necesaria</span><span class="ln oro">no garantiza</span><span class="ln">una buena inversión.</span></div>
  <div id="mark" class="clip" data-start="0" data-duration="{DUR}" data-track-index="5"><div class="logo" data-layout-allow-overflow><img src="assets/brand/TITAN_logo_referencia.jpg" alt="TITÁN Holding" /></div><span>TITÁN HOLDING</span></div>
  <div id="tx" class="clip" data-start="0" data-duration="{DUR}" data-track-index="6">{TEXTOS[V]}</div>
  <div id="tag" class="clip fx" data-start="0" data-duration="{DUR}" data-track-index="7">Recorrido ilustrativo</div>
  <div id="av" class="clip fx" data-layout-allow-overflow data-start="0" data-duration="{DUR}" data-track-index="8"><img id="avBg" src="assets/avatar/oficina.jpg" alt="" /><div id="avGlow"></div><div id="avIn">{imgs}</div></div>
  <div id="firma" class="clip fx" data-start="0" data-duration="{DUR}" data-track-index="9"><div class="logo" data-layout-allow-overflow><img src="assets/brand/TITAN_logo_referencia.jpg" alt="" /></div><b>TITÁN HOLDING</b></div>
  <div id="note" class="clip fx" data-start="0" data-duration="{DUR}" data-track-index="10">Contenido educativo · Invertir implica riesgos</div>
  {EXTRA[V].replace("{DUR}", str(DUR))}
</div>
<script>
const V = "{V}", P = {json.dumps(P)}, DUR = {DUR};
{JS}
</script></body></html>'''
    open(d + "/index.html", "w").write(html)
    json.dump({"version": V, "duracion": DUR, "frases": [[p[0], p[1], GUION[V][i]] for i, p in enumerate(P)]},
              open(d + "/tiempos.json", "w"), ensure_ascii=False, indent=1)
    print(V, DUR, P)
