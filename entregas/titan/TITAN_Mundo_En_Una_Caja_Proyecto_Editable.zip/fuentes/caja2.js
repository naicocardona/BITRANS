// ===== utilidades =====
const W = (p, k) => P[p][0] + (P[p][1] - P[p][0]) * k / P[p][2];   // instante aproximado de la palabra k de la frase p
const S0 = p => P[p][0], S1 = p => P[p][1];
const tl = gsap.timeline({ paused: true });
const E3 = "power3.out", IO = "power2.inOut";
const SY = 800, Z = 1.12;
function camV(cx, cy, s) { return { x: 540 - cx * s, y: SY - cy * s, scale: s }; }
function camSet(cx, cy, s) { gsap.set("#world", camV(cx, cy, s)); gsap.set("#far", { x: 540 - cx * s * 0.6, y: SY - cy * s, scale: s }); }
function cam(cx, cy, s, t, d, ease) {
  const v = camV(cx, cy, s);
  tl.to("#world", Object.assign({ duration: d, ease: ease || IO }, v), t);
  tl.to("#far", { x: 540 - cx * s * 0.6, y: v.y, scale: s, duration: d, ease: ease || IO }, t);
}
function inn(sel, t, o) { o = o || {}; tl.fromTo(sel, { opacity: 0, y: o.y === undefined ? 26 : o.y }, { opacity: 1, y: 0, duration: o.d || 0.45, ease: E3, immediateRender: false }, t); }
function out(sel, t, d) { tl.to(sel, { opacity: 0, duration: d || 0.3, ease: "power2.in" }, t); }
function head(id, a, b) {
  tl.fromTo(`#${id} .ln, #${id} .k`, { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.09, ease: E3, immediateRender: false }, a);
  tl.set("#" + id, { opacity: 1 }, a);
  if (b) tl.to("#" + id, { opacity: 0, duration: 0.25, ease: "power2.in" }, b - 0.25);
}
function pop(sel, t) { tl.fromTo(sel, { opacity: 0, scale: 0.3, transformOrigin: "50% 50%" }, { opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.8)", immediateRender: false }, t); }
function draw(sel, t, d) {
  document.querySelectorAll(sel).forEach(p => { const L = p.getTotalLength(); gsap.set(p, { strokeDasharray: L, strokeDashoffset: L }); });
  tl.to(sel, { strokeDashoffset: 0, duration: d || 0.6, ease: "power2.out", stagger: 0.08 }, t);
}
// ===== avatar TITÁN =====
const POSES = Array.from(document.querySelectorAll(".pose")).map(e => e.id);
const SCHED = [];   // [instante, pose] para programar parpadeos y manos
function pose0(n, t, d) { POSES.forEach(p => tl.to("#" + p, { opacity: p === n ? 1 : 0, duration: d, ease: "power1.inOut" }, t)); SCHED.push([t, n]); }
function pose(n, t) {
  const prev = SCHED.length ? SCHED[SCHED.length - 1][1] : null;
  // transiciones intermedias: neutral → brazo a medio camino → pose final
  if (n === "titan_senala_derecha" || n === "titan_pensativo") {
    const mid = n === "titan_senala_derecha" ? "titan_t_senala" : "titan_t_pensativo";
    if (prev !== "titan_neutral") { pose0("titan_neutral", t, 0.18); t += 0.2; }
    pose0(mid, t, 0.15); pose0(n, t + 0.22, 0.15);
  } else pose0(n, t, 0.25);
  tl.fromTo("#avIn", { scale: 1 }, { scale: 1.02, duration: 0.18, yoyo: true, repeat: 1, ease: "power1.out", immediateRender: false }, t);
}
function nod(t) {   // asentir: neutral → 1 → 2 → 3 → 2 → 1 → neutral
  [["titan_asiente_v2_1", 0], ["titan_asiente_v2_2", 0.16], ["titan_asiente_v2_3", 0.32], ["titan_asiente_v2_2", 0.48], ["titan_asiente_v2_1", 0.64], ["titan_neutral", 0.82]]
    .forEach(([n, dt]) => pose0(n, t + dt, 0.1));
}
function avShow(t, n) {
  POSES.forEach(p => tl.set("#" + p, { opacity: p === n ? 1 : 0 }, t)); SCHED.push([t, n]);
  tl.fromTo("#av", { opacity: 0, y: 120, scale: 0.92 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "back.out(1.4)", immediateRender: false }, t);
}
function avHide(t) { tl.to("#av", { opacity: 0, y: 120, duration: 0.35, ease: "power2.in" }, t); SCHED.push([t, null]); }
function lifeLayers() {   // parpadeo cada ~3,4 s y manos en bucle mientras explica (capas con el mismo cuerpo)
  const s = SCHED.slice().sort((a, b) => a[0] - b[0]);
  const on = (id, a, b, f) => { tl.to("#" + id, { opacity: 1, duration: f || 0.04 }, a); tl.to("#" + id, { opacity: 0, duration: f || 0.04 }, b); };
  s.forEach(([t0, n], i) => {
    const t1 = i + 1 < s.length ? s[i + 1][0] : DUR;
    if (n === "titan_neutral" || n === "titan_pensativo") {
      for (let t = t0 + 1.1; t < t1 - 0.5; t += 3.4) {
        if (n === "titan_neutral") { on("titan_neutral_ojos_entrecerrados", t, t + 0.07); on("titan_neutral_ojos_cerrados", t + 0.07, t + 0.17); on("titan_neutral_ojos_entrecerrados", t + 0.17, t + 0.24); }
        else on("titan_pensativo_ojos_cerrados", t, t + 0.14);
      }
    }
    if (n === "titan_explicando") {
      let c = 0;
      for (let t = t0 + 0.5; t < t1 - 0.7; t += 2.4, c++) {
        if (c % 2 === 0) on("titan_explicando_ojos_cerrados", t + 0.15, t + 0.29);
        if (t + 1.2 < t1 - 0.3) on("titan_explica_v2_2", t + 0.6, t + 1.2, 0.15);
        if (t + 2.4 < t1 - 0.3) on("titan_explica_v2_3", t + 1.8, t + 2.4, 0.15);
      }
    }
  });
}
tl.to("#avIn", { scaleY: 1.008, duration: 1.7, yoyo: true, repeat: Math.floor(DUR / 1.7), ease: "sine.inOut" }, 0);   // respiración

// ===== bucles discretos del mundo =====
tl.to(".belt", { strokeDashoffset: -32 * Math.ceil(DUR * 2.2), duration: DUR, ease: "none" }, 0);
tl.fromTo("#items", { x: 0 }, { x: 110, duration: 1.3, ease: "none", repeat: Math.floor(DUR / 1.3), immediateRender: false }, 0);
document.querySelectorAll(".puff").forEach((c, i) => tl.fromTo(c, { attr: { cy: 175, r: 14 }, opacity: 0.5 }, { attr: { cy: 60, r: 34 }, opacity: 0, duration: 2.4, ease: "none", repeat: Math.floor(DUR / 2.4), immediateRender: false }, i * 0.8));
tl.fromTo("#waves", { x: 0 }, { x: -120, duration: 2.2, ease: "none", repeat: Math.floor(DUR / 2.2), immediateRender: false }, 0);
tl.to("#ship", { y: -4, duration: 1.4, yoyo: true, repeat: Math.floor(DUR / 1.4), ease: "sine.inOut" }, 0);
tl.to("#arm", { y: 6, duration: 1.2, yoyo: true, repeat: Math.floor(DUR / 1.2), ease: "sine.inOut" }, 0);

// ===== estado inicial =====
camSet(2700, 450, 0.12);
gsap.set("#pk", { x: 5230, y: 574 });
gsap.set("#ct", { x: 1560, y: 574 });
gsap.set("#hook", { x: -55 });
gsap.set("#mini", { y: 300 });
document.querySelectorAll("#route").forEach(p => { const L = p.getTotalLength(); gsap.set(p, { strokeDasharray: L, strokeDashoffset: L }); });
gsap.set("#hQ", { opacity: 1 });

// ===== 1 · apertura: la caja se abre antes del segundo 2 =====
tl.to("#flapF", { scaleY: -1.5, transformOrigin: "50% 100%", duration: 0.45, ease: "back.out(1.6)" }, 0.15);
tl.to("#flapB", { scaleY: -2.3, transformOrigin: "50% 0%", duration: 0.5, ease: "back.out(1.6)" }, 0.25);
tl.to("#inside", { opacity: 1, duration: 0.3 }, 0.3);
tl.to("#rays", { opacity: 1, duration: 0.6, ease: "power1.out" }, 0.55);
tl.to("#mini", { y: 0, duration: 1.0, ease: "back.out(1.3)" }, 0.65);
const E = S1(0) + 0.15;                                  // entrar en el mundo
tl.to("#door", { scale: 5, opacity: 0, transformOrigin: "555px 937px", duration: 0.9, ease: "power2.in" }, E);
tl.to("#wwrap", { opacity: 1, duration: 0.5 }, E + 0.35);
cam(2700, 450, 0.19, E + 0.3, 1.1, "power2.out");
out("#hQ", E + 0.1, 0.3);

// ===== recorrido: rebobinar desde la puerta hasta la fábrica =====
function rewind(a, b) {
  tl.to("#route", { strokeDashoffset: 0, duration: b - a, ease: "power1.inOut" }, a);
  tl.to("#pk", { x: 905, y: 507, duration: b - a, ease: "power1.inOut" }, a);
}
function intoFactory(t) { cam(540, 400, Z, t, 1.2, "power3.inOut"); }
function press(t) { tl.to("#press", { attr: { y: 452 }, duration: 0.18, yoyo: true, repeat: 1, ease: "power2.in" }, t); }
function toPort(t) { cam(1640, 400, Z, t, 0.9); tl.to("#pk", { x: 1490, y: 574, duration: 0.9, ease: IO }, t); }
function portSeq(t, d) {   // caja entra al contenedor, la grúa lo sube y lo baja al barco
  const k = d / 2.3;
  tl.to("#pk", { x: 1560, scale: 0.3, opacity: 0, duration: 0.35 * k, ease: "power2.in" }, t);
  tl.to(["#ctGlow", "#ctBadge"], { opacity: 1, duration: 0.3 * k }, t + 0.25 * k);
  tl.to("#cable", { attr: { y2: 536 }, duration: 0.35 * k, ease: IO }, t + 0.35 * k); tl.to("#spr", { attr: { y: 536 }, duration: 0.35 * k, ease: IO }, t + 0.35 * k);
  tl.to("#cable", { attr: { y2: 330 }, duration: 0.4 * k, ease: IO }, t + 0.75 * k); tl.to("#spr", { attr: { y: 330 }, duration: 0.4 * k, ease: IO }, t + 0.75 * k);
  tl.to("#ct", { y: 368, duration: 0.4 * k, ease: IO }, t + 0.75 * k);
  tl.to("#hook", { x: 785, duration: 0.7 * k, ease: IO }, t + 1.15 * k); tl.to("#ct", { x: 2400, duration: 0.7 * k, ease: IO }, t + 1.15 * k);
  cam(2180, 400, Z, t + 1.1 * k, 0.8 * k);
  tl.to("#cable", { attr: { y2: 492 }, duration: 0.3 * k, ease: IO }, t + 1.85 * k); tl.to("#spr", { attr: { y: 492 }, duration: 0.3 * k, ease: IO }, t + 1.85 * k);
  tl.to("#ct", { y: 530, duration: 0.3 * k, ease: IO }, t + 1.85 * k);
  tl.to("#cable", { attr: { y2: 300 }, duration: 0.3 * k }, t + 2.2 * k); tl.to("#spr", { attr: { y: 300 }, duration: 0.3 * k }, t + 2.2 * k);
}
function shipSeq(t, d) {
  tl.to(["#ship"], { x: 400, duration: d, ease: "sine.inOut" }, t);
  tl.to("#ct", { x: 2800, duration: d, ease: "sine.inOut" }, t);
  cam(2700, 400, Z, t, 0.4); cam(3080, 400, Z, t + 0.4, d - 0.4, "sine.inOut");
}
function whSeq(t, d) {   // contenedor al muelle, la caja sale y pasa por el escáner
  const k = d / 2.3;
  cam(3870, 400, Z, t, 0.8 * k);
  tl.to("#ct", { keyframes: [{ x: 3150, y: 450, duration: 0.3 * k }, { x: 3485, y: 574, duration: 0.35 * k }], ease: "power1.inOut" }, t);
  tl.set("#pk", { x: 3485, y: 574, scale: 0.3, opacity: 0 }, t + 0.6 * k);
  tl.to("#pk", { x: 3560, y: 507, scale: 1, opacity: 1, duration: 0.35 * k, ease: "back.out(1.6)" }, t + 0.65 * k);
  tl.to("#pk", { x: 3945, duration: 0.6 * k, ease: "power1.inOut" }, t + 1.05 * k);
  tl.to("#beam", { opacity: 0.55, duration: 0.15 * k, yoyo: true, repeat: 1 }, t + 1.55 * k);
  tl.to("#pk", { x: 4200, duration: 0.5 * k, ease: "power1.inOut" }, t + 1.8 * k);
}
function vanLoad(t) { cam(4620, 400, Z, t, 0.8); tl.to("#pk", { x: 4470, y: 520, duration: 0.5, ease: IO }, t + 0.3); tl.to("#pk", { scale: 0.3, opacity: 0, duration: 0.3 }, t + 0.8); }
function closeSeq(t, door) {   // la furgoneta llega, la caja aparece en la puerta y volvemos a la caja inicial
  tl.set("#pk", { x: 4470, y: 520, scale: 0.3, opacity: 0 }, t - 0.6);
  tl.to("#wwrap", { opacity: 1, duration: 0.35 }, t - 0.5);
  cam(4760, 400, Z, t - 0.5, 0.01);
  tl.to("#van", { x: 300, duration: 1.1, ease: "power2.inOut" }, t - 0.3);
  tl.to(["#wh1"], { rotation: 540, svgOrigin: "4500 584", duration: 1.1, ease: "power2.inOut" }, t - 0.3);
  tl.to(["#wh2"], { rotation: 540, svgOrigin: "4700 584", duration: 1.1, ease: "power2.inOut" }, t - 0.3);
  cam(5150, 400, Z, t - 0.1, 1.0);
  tl.set("#pk", { x: 5100, y: 520 }, t + 0.75);
  tl.to("#pk", { x: 5230, y: 574, scale: 1, opacity: 1, duration: 0.4, ease: "back.out(1.6)" }, t + 0.8);
  tl.to("#door", { scale: 1, opacity: 1, transformOrigin: "555px 937px", duration: 0.9, ease: "power2.out" }, door);
  tl.to("#wwrap", { opacity: 0, duration: 0.5 }, door + 0.1);
  tl.to("#mini", { y: 300, duration: 0.6, ease: "power2.in" }, door + 0.9);
  tl.to("#rays", { opacity: 0, duration: 0.4 }, door + 0.9);
  tl.to("#inside", { opacity: 0, duration: 0.3 }, door + 1.3);
  tl.to("#flapB", { scaleY: 1, duration: 0.4, ease: "power2.inOut" }, door + 1.2);
  tl.to("#flapF", { scaleY: 1, duration: 0.4, ease: "power2.inOut" }, door + 1.35);
}
function netIn(t, sp) {   // red de negocios conectados
  tl.to("#wwrap", { opacity: 0, duration: 0.45 }, t);
  cam(2700, 450, 0.12, t - 0.2, 0.7, "power2.in");
  tl.to("#net", { opacity: 1, duration: 0.4 }, t + 0.2);
  pop("#nCore", t + 0.2);
  draw("#net .nl", t + 0.4, 0.5);
  const ns = ["#n1", "#n2", "#n3", "#n4"];
  ns.forEach((n, i) => pop(n, sp[i]));
  draw("#net .nr", sp[3] + 0.2, 0.5);
  const tp = sp[3] + 0.8;
  [["#pl1", 260, 600, 780, 600], ["#pl2", 780, 600, 780, 900], ["#pl3", 780, 900, 260, 900], ["#pl4", 260, 900, 260, 600]].forEach(([id, x1, y1, x2, y2]) => {
    tl.fromTo(id, { attr: { cx: x1, cy: y1 }, opacity: 1 }, { attr: { cx: x2, cy: y2 }, duration: 1.6, ease: "none", repeat: 30, immediateRender: false }, tp);
  });
}
function mag(t, x, y, first) {
  if (first) { tl.set("#mag", { x, y }, t); tl.to("#mag", { opacity: 1, duration: 0.3 }, t); }
  else tl.to("#mag", { x, y, duration: 0.55, ease: IO }, t);
}

// ===== versiones =====
if (V === "shorts") {
  // 2 · su historia empezó mucho antes
  head("h2", E + 0.85, S1(1) + 0.2);
  tl.to("#tag", { opacity: 1, duration: 0.4 }, S0(1) + 0.4);
  rewind(S0(1) + 0.7, S1(1) - 1.1);
  intoFactory(S1(1) - 1.0);
  avShow(S0(1) + 0.2, "titan_rostro_sorpresa"); pose("titan_explicando", W(1, 6)); nod(S1(1) - 1.4); avHide(S1(1) - 0.2);
  // 3 · fábrica, puerto, barco, almacén
  const a = S0(2), seg = (S1(2) - a + 0.5) / 4;
  head("hF", a, a + seg); press(a + 0.3);
  toPort(a + seg - 0.55); head("hP", a + seg, a + 2 * seg); portSeq(a + seg + 0.2, seg - 0.2);
  head("hB", a + 2 * seg, a + 3 * seg); shipSeq(a + 2 * seg, seg);
  head("hA", a + 3 * seg, S0(3)); whSeq(a + 3 * seg, seg);
  tl.to("#tag", { opacity: 0, duration: 0.3 }, S0(3) - 0.1);
  // 4 · una compra, distintos negocios
  head("h4", S0(3), S0(4));
  netIn(S0(3) - 0.2, [W(3, 7), W(3, 9), W(3, 11), W(3, 13)]);
  avShow(S0(3) + 0.2, "titan_senala_derecha");
  // 5 · mirar detrás de lo que compramos
  head("h5", S0(4), S0(5));
  pose("titan_idea", S0(4));
  mag(S0(4) + 0.4, 260, 600, true); mag(S0(4) + 1.6, 780, 600); mag(S0(4) + 2.8, 780, 900); mag(S0(4) + 4.0, 260, 900);
  out("#mag", S1(4) + 0.2);
  // 6 · el matiz
  tl.to("#net", { opacity: 0, duration: 0.3 }, S0(5) - 0.4);
  head("hRk", S0(5), S1(5) + 0.4);
  tl.set("#rk", { opacity: 1 }, S0(5));
  tl.fromTo("#rk .ln", { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.12, ease: E3, immediateRender: false }, S0(5) + 0.1);
  pose("titan_alto", S0(5)); pose("titan_duda", W(5, 16));
  inn("#cp1", W(5, 19)); inn("#cp2", W(5, 21)); inn("#cp3", W(5, 24));
  avHide(S1(5) + 0.1);
  const C = S0(6);
  out(["#rk", "#cp1", "#cp2", "#cp3", "#net"], C - 0.8, 0.35);
  closeSeq(C - 0.2, C + 1.0);
  head("h7", C, null);
  inn("#firma", S1(6) + 0.3, { y: 16 }); inn("#note", S1(6) + 0.5, { y: 10 });
} else {
  // 2 · un paquete más… negocios conectados
  head("h2", E + 0.85, S1(1) + 0.2);
  tl.to("#tag", { opacity: 1, duration: 0.4 }, S0(1) + 0.4);
  rewind(S0(1) + 0.8, S1(1) - 1.6);
  intoFactory(S1(1) - 1.3);
  avShow(S0(1) + 0.2, "titan_rostro_sorpresa"); pose("titan_explicando", W(1, 9)); nod(S1(1) - 1.8); avHide(S1(1) - 0.6);
  // 3 · producción
  head("hF", S0(2), S1(2) + 0.3);
  cam(560, 410, 1.24, S0(2), S1(2) - S0(2), "sine.inOut");
  inn("#st1", W(2, 7)); inn("#st2", W(2, 8)); inn("#st3", W(2, 10)); press(W(2, 8));
  out(["#st1", "#st2", "#st3"], S1(2) + 0.1);
  // 4 · puerto, contenedor, barco, almacén, reparto
  toPort(S1(2) + 0.1);
  const pa = S0(3), pb = W(3, 12), pc = W(3, 17), pd = W(3, 24.5);
  head("hP", pa, pb); portSeq(pa + 0.3, pb - pa - 0.3);
  head("hB", pb, pc); shipSeq(pb, pc - pb);
  head("hA", pc, pd); whSeq(pc, pd - pc);
  head("hR", pd, S1(3) + 0.5); vanLoad(pd);
  // 5 · no todos los pedidos siguen esa ruta
  cam(2700, 450, 0.19, S0(4) - 0.3, 1.0);
  head("h5a", S0(4), W(4, 16));
  tl.to("#alts", { opacity: 1, duration: 0.5 }, S0(4) + 0.5);
  tl.fromTo("#alts path", { strokeDashoffset: 0 }, { strokeDashoffset: -296, duration: 4, ease: "none", repeat: 2, immediateRender: false }, S0(4) + 0.5);
  avShow(S0(4) + 0.2, "titan_niega");
  tl.to(["#tag", "#alts"], { opacity: 0, duration: 0.3 }, W(4, 16) - 0.2);
  head("h4", W(4, 16), W(5, 8));
  netIn(W(4, 16) - 0.2, [W(4, 17), W(4, 19), W(4, 21), W(4, 23)]);
  pose("titan_senala_derecha", W(4, 16));
  // 6 · preguntas para investigar
  pose("titan_idea", S0(5));
  head("q1", W(5, 9), W(5, 11)); mag(W(5, 9), 260, 600, true); pose("titan_explicando", W(5, 9));
  head("q2", W(5, 11), W(5, 15)); mag(W(5, 11), 780, 600);
  head("q3", W(5, 15), W(5, 19)); mag(W(5, 15), 780, 900);
  head("q4", W(5, 19), S1(5) + 0.4); mag(W(5, 19), 520, 750);
  tl.to("#mag", { scale: 1.6, svgOrigin: "520 750", duration: 0.5, ease: IO }, W(5, 19) + 0.6);
  // 7 · otras preguntas
  out(["#net", "#mag"], S1(5) + 0.2, 0.4);
  head("h7", S0(6), S1(6) + 0.3);
  pose("titan_pensativo", S0(6));
  inn("#qc1", W(6, 4)); inn("#qc2", W(6, 8)); inn("#qc3", W(6, 12));
  out(["#qc1", "#qc2", "#qc3"], S1(6) + 0.1);
  // 8 · el matiz
  head("hRk", S0(7), S1(7) + 0.4);
  tl.set("#rk", { opacity: 1 }, S0(7));
  tl.fromTo("#rk .ln", { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.5, stagger: 0.12, ease: E3, immediateRender: false }, S0(7) + 0.1);
  pose("titan_alto", S0(7)); pose("titan_duda", W(7, 10));
  inn("#cp1", W(7, 14)); inn("#cp2", W(7, 20)); inn("#cp3", W(7, 23));
  avHide(S1(7) + 0.2);
  // 9 · mira más allá de la caja → vuelve a la puerta
  const C = S0(8);
  out(["#rk", "#cp1", "#cp2", "#cp3"], C - 0.6, 0.35);
  closeSeq(C, S1(8) - 1.2);
  head("h9", C, S0(9));
  // 10 · pregunta final
  head("h10", S0(9), null);
  inn("#firma", S1(9) + 0.3, { y: 16 }); inn("#note", S1(9) + 0.5, { y: 10 });
}
lifeLayers();
tl.to({}, { duration: 0.01 }, DUR - 0.01);
window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl;
