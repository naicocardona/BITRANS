# TITÁN · «¿Quién manda?» · Proyecto editable

- `tq-tiktok/`, `tq-shorts/`, `tq-largo/`: composiciones HyperFrames 0.8.134. Para renderizar, entra a la carpeta y ejecuta `npx --yes hyperframes@0.8.134 render --fps 30 -o render.mp4`.
- Cada carpeta tiene `tiempos.json`, con las anclas de cada escena (en segundos) y los grupos de subtítulos.
- `portada_v/` y `portada_h/`: portadas editables.
- `voz/originales_elevenlabs/`: audios originales de ElevenLabs (voz «Juan - Clear & Expressive»).
- `voz/editadas/`: tiempo de cada palabra de las narraciones con las pausas ajustadas. El audio ajustado se regenera desde los originales con `tighten.py` (0,32 s en verticales y 0,4 s en el largo).
- `scripts/`: generadores. `build_tq.py` arma las tres versiones a partir de la voz: las escenas entran con la frase exacta, así que si cambia el audio, el montaje se resincroniza solo.
- La voz editada va en FLAC (sin pérdida). La mezcla final de cada versión va en AAC de 192 kbps para que el ZIP pese menos de 30 MB; con `mix_tq.py` se puede regenerar sin pérdida.
