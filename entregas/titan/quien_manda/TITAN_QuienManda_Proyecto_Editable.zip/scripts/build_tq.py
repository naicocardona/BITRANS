# TITÁN HOLDING · «Pones dinero. ¿Pero quién manda?» · TikTok, Shorts (1080×1920) y YouTube largo (1920×1080)
import os, sys, json, re, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tq_body_v import body_v
from tq_body_h import body_h
SCR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
VZ = f"{SCR}/tq/voz/t"
def norm(w): return re.sub(r"[^\wáéíóúñü%]", "", w.lower())
class Anchors:
    def __init__(s, W): s.W = W; s.N = [norm(w[0]) for w in W]; s.i = 0
    def __call__(s, phrase, seq=True):
        ks = [norm(x) for x in phrase.split()]
        for i in range(s.i if seq else 0, len(s.N) - len(ks) + 1):
            if s.N[i:i + len(ks)] == ks:
                if seq: s.i = i + 1
                return round(s.W[i][1], 3)
        raise SystemExit(f"ancla no encontrada: «{phrase}»")
def anchors(V, W):
    a = Anchors(W); A = {}
    if V == "tiktok":
        A["own1"] = a("ahora soy dueño"); A["own2"] = a("¿también tienes voto?"); A["news"] = a("Meta anunció"); A["d2"] = a("19 de enero")
        A["cls"] = a("Su documentación"); A["cA"] = a("de clase A"); A["cB"] = a("de clase B"); A["cC"] = a("la nueva clase C")
        A["ev"] = a("Eso no significa"); A["evR"] = a("Significa que participar"); A["q2"] = a("Piensa en dos preguntas")
        A["qa"] = a("¿qué participación tengo?"); A["qb"] = a("¿qué decisiones"); A["inf"] = a("Una acción con voto tampoco"); A["infN"] = a("tu influencia")
        A["ck"] = a("Para quien empieza"); A["ckT"] = [a("no basta"), a("También hay que entender"), a("el negocio,"), a("sus riesgos"), a("el precio.")]
        A["ckP"] = a("Ninguna clase de acción"); A["cta"] = a("¿Tú aceptarías")
    elif V == "shorts":
        A["news"] = a("Meta anunció"); A["d2"] = a("enero de 2027"); A["ev"] = a("La diferencia importa"); A["evR"] = a("sin darte")
        A["ck"] = a("Por eso,"); A["ckT"] = [a("del negocio"), a("el precio,"), a("qué clase de acción"), a("qué derechos incluye")]
        A["ckP"] = a("Esto no demuestra"); A["cta"] = a("¿Aceptarías")
    else:
        A["neq"] = a("Tener participación económica"); A["news"] = a("En octubre de 2026"); A["doc"] = a("Según su documentación")
        A["hl2"] = a("una fecha efectiva prevista"); A["d2"] = a("el 19 de enero"); A["hl1"] = a("La característica central")
        A["myth"] = a("Esto no significa"); A["m1"] = a("pierdan sus votos"); A["m2"] = a("ni que la clase C"); A["m3"] = a("Lo que cambia")
        A["cls"] = a("Veamos las tres clases"); A["gA"] = a("La clase A da"); A["gB"] = a("La clase B da"); A["gC"] = a("Y la nueva clase C")
        A["not"] = a("Un detalle importante"); A["n1"] = a("del precio"); A["n2"] = a("de su rentabilidad"); A["n3"] = a("de cuánto vale"); A["n4"] = a("Una acción con 10 votos")
        A["avail"] = a("Y algo más"); A["av1"] = a("Antes de dar algo")
        A["ex"] = a("Para verlo con números"); A["tok"] = a("con 100 acciones"); A["kB"] = a("10 acciones son de clase B"); A["kA"] = a("40 son de clase A"); A["kC"] = a("Y 50 son de clase C")
        A["bE"] = a("Para simplificar"); A["mB"] = a("10 acciones de clase B, con 10 votos"); A["mA"] = a("40 acciones de clase A suman"); A["mC"] = a("La clase C suma"); A["mT"] = a("En total hay")
        A["bV"] = a("Los fundadores, con el 10%"); A["exR"] = a("más del 71%"); A["one"] = a("Ahora piensa en una sola persona")
        A["app"] = a("¿Por qué le importa"); A["apI"] = a("Pero detrás de ese símbolo"); A["s1"] = a("El primer paso"); A["s2"] = a("El segundo paso")
        A["brk"] = a("Y hay una diferencia más"); A["brkN"] = a("No todos los brókers")
        A["qs"] = a("Antes de comprar una acción, estas son"); A["qT"] = [a("Primera:"), a("Segunda:"), a("Tercera:"), a("Cuarta:"), a("Y quinta:")]
        A["qP"] = a("Ninguna de estas preguntas"); A["bal"] = a("Entonces, ¿una estructura"); A["pl1"] = a("Concentrar el control"); A["pl2"] = a("Pero también puede limitar")
        A["plP"] = a("No es un veredicto"); A["cta"] = a("Y tú, ¿invertirías")
    return A
def groups(W, mx):
    G, cur = [], []
    for k, w in enumerate(W):
        cur.append(w); nxt = W[k + 1] if k + 1 < len(W) else None
        if len(cur) >= mx or re.search(r"[.,:;?!]$", w[0]) or not nxt or nxt[1] - w[2] > 0.28:
            G.append(cur); cur = []
    out = []
    for k, g in enumerate(G):
        end = G[k + 1][0][1] if k + 1 < len(G) else g[-1][2] + 1.0
        out.append([round(g[0][1], 3), round(min(end, g[-1][2] + 0.6), 3), g])
    return out
KEYS = {"voto", "votos", "meta", "sin"}
def caps_html(G, fs):
    h = ""
    for i, (a, b, g) in enumerate(G):
        sp = ""
        for j, w in enumerate(g):
            t = w[0].strip("«»"); k = " k" if (re.search(r"\d", t) or norm(t) in KEYS) else ""
            sp += f'<span class="cw{k}" id="cw{i}_{j}" style="margin:0 6px">{t}</span>'
        h += f'<div class="cg" id="cg{i}" style="font-size:{fs}px">{sp}</div>'
    return h
for V in ["tiktok", "shorts", "largo"]:
    src = {"tiktok": "tiktok", "shorts": "shorts_t1", "largo": "largo"}[V]
    d = json.load(open(f"{VZ}/{src}.words.json")); W = d["display"]
    H = V == "largo"; Wd, Hd = (1920, 1080) if H else (1080, 1920)
    A = anchors(V, W); tail = 4.2 if H else 3.4; DUR = round(d["dur"] + tail, 2)
    G = groups(W, 4 if H else 3)
    p = f"{SCR}/tq-{V}"
    for sub in ["fonts", "vendor", "brand", "audio"]: os.makedirs(f"{p}/assets/{sub}", exist_ok=True)
    fp = f"{SCR}/tq/fontpkg"
    for n, f in [("bricolage-800", "x_fontsource-bricolage-grotesque-5.3.0/package/files/bricolage-grotesque-latin-800-normal.woff2"), ("bricolage-700", "x_fontsource-bricolage-grotesque-5.3.0/package/files/bricolage-grotesque-latin-700-normal.woff2"),
                 ("jakarta-600", "x_fontsource-plus-jakarta-sans-5.3.0/package/files/plus-jakarta-sans-latin-600-normal.woff2"), ("jakarta-700", "x_fontsource-plus-jakarta-sans-5.3.0/package/files/plus-jakarta-sans-latin-700-normal.woff2"),
                 ("jakarta-800", "x_fontsource-plus-jakarta-sans-5.3.0/package/files/plus-jakarta-sans-latin-800-normal.woff2"), ("caveat-700", "x_fontsource-caveat-5.3.0/package/files/caveat-latin-700-normal.woff2")]:
        shutil.copy(f"{fp}/{f}", f"{p}/assets/fonts/{n}.woff2")
    shutil.copy(f"{SCR}/titan-caja/assets/vendor/gsap.min.js", f"{p}/assets/vendor/")
    shutil.copy("/home/user/BITRANS/entregas/titan/marca/TITAN_logo_referencia.jpg", f"{p}/assets/brand/logo.jpg")
    shutil.copy(f"{SCR}/titan-caja/hyperframes.json", p)
    json.dump({"name": f"tq-{V}", "private": True, "type": "module"}, open(p + "/package.json", "w"))
    json.dump({"id": f"tq-{V}", "name": f"tq-{V}"}, open(p + "/meta.json", "w"))
    body = body_h() if H else body_v(V)
    body = body.replace("{CAPS}", caps_html(G, 54 if H else 66)).replace("{DUR}", str(DUR))
    n = [0]
    def ti(m): n[0] += 1; return str(n[0])
    body = re.sub(r"\{TI\}", ti, body)
    CSS = open(f"{SCR}/tools/tq.css").read(); JS = open(f"{SCR}/tools/tq_core.js").read() + open(f"{SCR}/tools/{'tq_h' if H else 'tq_v'}.js").read()
    html = f'''<!doctype html><html lang="es"><head><meta charset="UTF-8" /><meta name="viewport" content="width={Wd}, height={Hd}" />
<title>TITÁN HOLDING · ¿Quién manda? · {V}</title><script src="assets/vendor/gsap.min.js"></script>
<style>{CSS}
html, body, #root {{ width:{Wd}px; height:{Hd}px; }}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{DUR}" data-width="{Wd}" data-height="{Hd}">
{body}
<audio id="vo" src="assets/audio/mix.wav" data-start="0" data-duration="{DUR}" data-track-index="90" data-volume="1"></audio>
</div>
<script>
const V = "{V}", DUR = {DUR}, A = {json.dumps(A)};
const CG = {json.dumps([[a, b, [[w[1], w[2]] for w in g]] for a, b, g in G])};
{JS}
</script></body></html>'''
    open(p + "/index.html", "w").write(html)
    json.dump({"version": V, "duracion": DUR, "anclas": A, "subtitulos": [[a, b, " ".join(w[0] for w in g)] for a, b, g in G]}, open(p + "/tiempos.json", "w"), ensure_ascii=False, indent=1)
    print(V, DUR, len(G), "grupos de subtítulos")
