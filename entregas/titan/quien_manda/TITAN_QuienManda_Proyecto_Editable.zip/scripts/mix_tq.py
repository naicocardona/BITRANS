# Voz ElevenLabs al frente + fondo instrumental casi inaudible (distinto por versión) + efectos mínimos → −14 LUFS
import json, subprocess
S = "/tmp/claude-0/-home-user-BITRANS/e6df0451-e894-56da-93e1-0311b18c22a2/scratchpad"
for v, src, var in [("tiktok", "tiktok", "tqtk"), ("shorts", "shorts_t1", "tqsh"), ("largo", "largo", "tqlg")]:
    d = json.load(open(f"{S}/tq-{v}/tiempos.json")); DUR = d["duracion"]; A = d["anclas"]
    keys = {"tiktok": ["news", "cls", "ev", "q2", "inf", "ck", "cta"], "shorts": ["news", "ev", "ck", "cta"],
            "largo": ["news", "myth", "cls", "avail", "ex", "app", "qs", "bal", "cta"]}[v]
    ev = [[A[k] - 0.25, "whoosh"] for k in keys] + [[A["cta"] + 2.6, "ping"]]
    o = f"{S}/tq-{v}/assets/audio"
    subprocess.run(["python3", f"{S}/tools/bed_music.py", f"{o}/bed.wav", str(DUR), var], check=True, capture_output=True)
    subprocess.run(["python3", f"{S}/tools/sfx_mix.py", f"{o}/bed.wav", f"{o}/bedfx.wav", str(DUR), json.dumps(ev)], check=True, capture_output=True)
    voice = f"{S}/tq/voz/t/{src}.wav"
    fc = (f"[0]aresample=48000,volume=0.11,afade=t=out:st={DUR-2.5}:d=2.5[m];"
          f"[1]aresample=48000,highpass=f=60,acompressor=threshold=-22dB:ratio=2.2:attack=8:release=150:makeup=1.5,aformat=channel_layouts=stereo,adelay=0|0,apad=whole_dur={DUR},asplit[v][sc];"
          f"[m][sc]sidechaincompress=threshold=0.02:ratio=8:attack=15:release=400[md];[md][v]amix=inputs=2:normalize=0:duration=longest,atrim=0:{DUR},loudnorm=I=-14:TP=-1.5:LRA=11")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", f"{o}/bedfx.wav", "-i", voice, "-filter_complex", fc, "-ar", "48000", f"{o}/mix.wav"], check=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", f"{o}/mix.wav", "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
    print(v, DUR, [l.strip() for l in r.split("Summary")[1].splitlines() if "I:" in l][0])
