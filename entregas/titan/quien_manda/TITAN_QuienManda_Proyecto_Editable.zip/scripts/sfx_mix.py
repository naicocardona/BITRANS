# Uso: sfx_mix.py <bed.wav> <out.wav> <dur> '<json [[t,"tipo"],...]>'
# Efectos originales sintetizados (numpy): impact, stamp, whoosh, ping. Mezcla con la música de fondo.
import sys, json, numpy as np, soundfile as sf
bed, out, DUR, EV = sys.argv[1], sys.argv[2], float(sys.argv[3]), json.loads(sys.argv[4])
SR = 44100
b, sr = sf.read(bed, always_2d=True)
N = int(DUR * SR)
mix = np.zeros((N, 2)); mix[:min(N, len(b))] = b[:N] * 0.85
rng = np.random.default_rng(7)
def T(d): return np.arange(int(d * SR)) / SR
def lp(x, a):  # filtro paso bajo de un polo
    y = np.zeros_like(x); acc = 0.0
    for i in range(len(x)): acc += a * (x[i] - acc); y[i] = acc
    return y
def impact():
    t = T(0.6)
    body = np.sin(2 * np.pi * np.cumsum(90 * np.exp(-t * 9) + 38) / SR) * np.exp(-t * 6)
    click = rng.uniform(-1, 1, len(t)) * np.exp(-t * 70) * 0.5
    return (body + click) * 0.9
def stamp():
    t = T(0.45)
    body = np.sin(2 * np.pi * np.cumsum(140 * np.exp(-t * 14) + 60) / SR) * np.exp(-t * 9)
    snap = lp(rng.uniform(-1, 1, len(t)), 0.35) * np.exp(-t * 40)
    return (body * 0.8 + snap * 0.9) * 0.8
def whoosh():
    t = T(0.42)
    n = rng.uniform(-1, 1, len(t))
    env = np.sin(np.pi * np.clip(t / 0.42, 0, 1)) ** 2
    return lp(n, 0.08) * env * 1.1
def ping():
    t = T(0.9)
    return (np.sin(2 * np.pi * 1318.5 * t) * 0.5 + np.sin(2 * np.pi * 1975.5 * t) * 0.25) * np.exp(-t * 5) * 0.35
F = {"impact": impact, "stamp": stamp, "whoosh": whoosh, "ping": ping}
G = {"impact": 0.55, "stamp": 0.5, "whoosh": 0.22, "ping": 0.3}
for t0, kind in EV:
    x = F[kind]() * G[kind]; i = int(t0 * SR); j = min(N, i + len(x))
    if i < N: mix[i:j] += np.stack([x[:j - i], x[:j - i]], 1)
peak = np.max(np.abs(mix)) + 1e-9
if peak > 0.95: mix *= 0.95 / peak
sf.write(out, mix, SR); print("ok", len(EV), "efectos")
