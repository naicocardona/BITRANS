# Cuerpo horizontal 1920×1080 (YouTube largo): composición propia
from tq_parts import *
def body_h():
    P = ['<div id="dots"></div>', '<div id="ivo"></div>']
    P.append(clip("brand", LOGO + "<span>TITÁN HOLDING</span>", style="left:48px;top:40px"))
    for k, t in enumerate(["LA NOTICIA", "TRES CLASES, DISTINTOS VOTOS", "UN EJEMPLO SENCILLO", "PARA QUIEN EMPIEZA", "CINCO PREGUNTAS", "CONCLUSIÓN"], 1):
        P.append(clip(f"sec{k}", t, "chip fx", "left:430px;top:56px;font-size:20px"))
    # 1 gancho
    P.append(clip("hook", '<div class="l l1" style="font-size:82px">Eres accionista.</div><br/><div class="l l2" style="font-size:82px;margin-left:80px">¿Tienes voto?</div>', "hk", "left:100px;top:250px"))
    fichas = "".join(ficha(f"f{c}", k * 290, 0, 270, 420, c, 0.92) for k, c in enumerate("ABC"))
    P.append(clip("fich", fichas + '<div class="legend fx" id="leg" style="left:0;top:440px;width:850px;font-size:22px">VOTOS POR ACCIÓN · NO ES PRECIO NI RENTABILIDAD</div>', "", "position:absolute;left:990px;top:250px;width:860px;height:500px"))
    P.append(clip("neq", '<div class="pill" style="left:0;top:0;padding:16px 30px;font-size:34px;background:var(--ivory);color:var(--navy)">Participación económica</div>'
                  '<div class="B gold" style="position:absolute;left:470px;top:-6px;font-size:64px">≠</div>'
                  '<div class="pill" style="left:540px;top:0;padding:16px 30px;font-size:34px;background:var(--gold);color:var(--navy)">Voto</div>', "fx", "position:absolute;left:110px;top:600px;width:820px;height:90px"))
    # 2 noticia + documento ilustrado
    P.append(clip("news", '<div class="k" style="position:absolute;left:44px;top:38px;font-size:20px;white-space:nowrap">META · OCTUBRE 2026 · RESULTADOS DEL 3.<sup>er</sup> TRIMESTRE</div>'
        '<div class="t" style="position:absolute;left:44px;top:80px;font-size:76px">Nueva clase C</div>'
        '<div class="pill" style="left:44px;top:186px;padding:10px 24px;font-size:28px;background:var(--navy);color:var(--gold)">Sin voto ordinario*</div>'
        '<div style="position:absolute;left:80px;top:360px;width:700px;height:6px;background:rgba(11,27,51,.2);border-radius:3px"></div>'
        '<div id="tlF" style="position:absolute;left:80px;top:360px;width:700px;height:6px;background:var(--navy);border-radius:3px;transform-origin:0 50%"></div>'
        '<div style="position:absolute;left:64px;top:344px;width:38px;height:38px;border-radius:50%;background:var(--navy)"></div>'
        '<div class="fx" id="d2" style="position:absolute;left:762px;top:344px;width:38px;height:38px;border-radius:50%;background:var(--gold);border:5px solid var(--navy)"></div>'
        '<div style="position:absolute;left:44px;top:400px;font-weight:800;font-size:28px">OCT 2026<br/><span style="font-weight:700;font-size:22px;opacity:.7">anunciada</span></div>'
        '<div class="fx" id="d2t" style="position:absolute;left:520px;top:400px;width:300px;text-align:right;font-weight:800;font-size:28px">19 ENE 2027<br/><span style="font-weight:700;font-size:22px;color:var(--gtx)">fecha efectiva prevista</span></div>'
        '<div class="src" style="left:44px;top:520px;width:780px;font-size:18px">*Salvo excepciones previstas en los documentos y la ley · Fuente: documentos de Meta, oct. 2026</div>',
        "card fx", "left:110px;top:200px;width:860px;height:580px"))
    doc = ('<div style="position:absolute;left:30px;top:26px;font-weight:800;font-size:18px;letter-spacing:.14em;color:rgba(11,27,51,.55)">DOCUMENTO DE LA EMPRESA · ILUSTRACIÓN</div>'
           + "".join(f'<div style="position:absolute;left:30px;top:{80+i*34}px;width:{[560,520,590,480,560,540,600,500,470,580,520,560][i]}px;height:12px;border-radius:6px;background:rgba(11,27,51,.14)"></div>' for i in range(12))
           + '<div class="fx" id="hl1" style="position:absolute;left:22px;top:174px;width:600px;height:46px;border-radius:10px;background:rgba(226,183,85,.85);display:flex;align-items:center;padding-left:16px;font-weight:800;font-size:22px">Clase C · sin voto ordinario, salvo excepciones</div>'
           + '<div class="fx" id="hl2" style="position:absolute;left:22px;top:310px;width:600px;height:46px;border-radius:10px;background:rgba(226,183,85,.85);display:flex;align-items:center;padding-left:16px;font-weight:800;font-size:22px">Fecha efectiva prevista: 19 ene 2027</div>')
    P.append(clip("doc", doc, "card fx", "left:1080px;top:230px;width:660px;height:520px;transform:rotate(2deg)"))
    P.append(clip("myth", '<div class="B" style="position:absolute;left:0;top:0;font-size:72px">Lo que <span class="gold">no</span> significa</div>'
                  '<div class="pill fx" id="m1" style="left:0;top:110px;padding:20px 34px;font-size:40px;background:rgba(179,38,30,.16);border:3px solid #E57368;color:var(--ivory)">✕ Que los accionistas actuales pierdan sus votos</div>'
                  '<div class="pill fx" id="m2" style="left:0;top:240px;padding:20px 34px;font-size:40px;background:rgba(179,38,30,.16);border:3px solid #E57368;color:var(--ivory)">✕ Que la clase C deje de ser participación económica</div>'
                  '<div class="pill fx" id="m3" style="left:0;top:400px;padding:20px 34px;font-size:42px;background:var(--gold);color:var(--navy)">Cambia la combinación de derechos de cada clase</div>', "fx", "position:absolute;left:110px;top:250px;width:1500px;height:500px"))
    # 3 clases
    cols = "".join(ficha(f"g{c}", k * 420, 0, 380, 520, c, 1.18) for k, c in enumerate("ABC"))
    P.append(clip("cls", '<div class="legend" style="left:0;top:-70px;width:1220px;font-size:28px">VOTOS POR ACCIÓN</div>' + cols, "fx", "position:absolute;left:350px;top:200px;width:1220px;height:560px"))
    P.append(clip("not", '<div class="pill fx" id="n1" style="left:0;top:0;padding:14px 26px;font-size:30px;background:rgba(244,238,220,.1);border:2px solid rgba(244,238,220,.4)"><s>Precio</s></div>'
                  '<div class="pill fx" id="n2" style="left:230px;top:0;padding:14px 26px;font-size:30px;background:rgba(244,238,220,.1);border:2px solid rgba(244,238,220,.4)"><s>Rentabilidad</s></div>'
                  '<div class="pill fx" id="n3" style="left:520px;top:0;padding:14px 26px;font-size:30px;background:rgba(244,238,220,.1);border:2px solid rgba(244,238,220,.4)"><s>Valor de mercado</s></div>'
                  '<div class="pill fx" id="n4" style="left:900px;top:0;padding:14px 26px;font-size:30px;background:var(--gold);color:var(--navy)">10 votos ≠ 10 veces el valor</div>', "fx", "position:absolute;left:250px;top:780px;width:1500px;height:90px"))
    P.append(clip("avail", '<div class="B" style="font-size:76px;line-height:1.05">Existe en los documentos<br/><span class="gold">≠ disponible para comprar hoy</span></div>'
                  '<div class="pill fx" id="av1" style="left:0;top:250px;padding:18px 30px;font-size:34px;background:var(--ivory);color:var(--navy)">Revisa qué está disponible y en qué condiciones</div>', "fx", "position:absolute;left:150px;top:300px;width:1600px;height:400px"))
    # 4 ejemplo conceptual
    grid = ""
    for i in range(100):
        c = "B" if i < 10 else ("A" if i < 50 else "C")
        grid += f'<div class="tok t{c}" id="tk{i}" style="left:{(i%10)*50}px;top:{(i//10)*50}px"></div>'
    ex = ('<div class="tag" style="left:0;top:0;font-size:22px">EJEMPLO CONCEPTUAL · EMPRESA FICTICIA</div>'
          '<div style="position:absolute;left:0;top:50px;font-weight:800;font-size:26px">100 ACCIONES</div>'
          f'<div id="grid" style="position:absolute;left:0;top:96px;width:500px;height:500px">{grid}</div>'
          '<div class="fx" id="lgd" style="position:absolute;left:0;top:610px;font-weight:800;font-size:22px;display:flex;flex-direction:column;gap:8px"><span><i class="sw tB"></i>Clase B · 10 votos</span><span><i class="sw tA"></i>Clase A · 1 voto</span><span><i class="sw tC"></i>Clase C · sin voto ordinario</span></div>')
    def bar(i, y, title, segs):
        h = f'<div style="position:absolute;left:0;top:{y}px;font-weight:800;font-size:24px;letter-spacing:.06em">{title}</div><div id="{i}" style="position:absolute;left:0;top:{y+40}px;width:900px;height:70px;border-radius:12px;overflow:hidden;display:flex;background:rgba(244,238,220,.08)">'
        for c, w, lab in segs:
            h += f'<div class="seg t{c}" id="{i}{c}" style="width:{w}%;height:100%;display:flex;align-items:center;justify-content:center;font-family:Bricolage;font-weight:800;font-size:28px;color:var(--navy);transform-origin:0 50%">{lab}</div>'
        return h + "</div>"
    ex2 = (bar("bE", 0, "PARTICIPACIÓN ECONÓMICA (supuesto: igual por acción)", [("B", 10, "10 %"), ("A", 40, "40 %"), ("C", 50, "50 %")])
           + '<div class="fx" id="math" style="position:absolute;left:0;top:150px;font-weight:800;font-size:30px;line-height:1.6">'
             '<div class="fx" id="m_b">B · 10 acciones × 10 votos = <b class="gold">100 votos</b></div><div class="fx" id="m_a">A · 40 acciones × 1 voto = <b class="gold">40 votos</b></div>'
             '<div class="fx" id="m_c">C · 50 acciones × 0 votos ordinarios = <b class="gold">0</b></div><div class="fx" id="m_t" style="border-top:2px solid rgba(244,238,220,.3);margin-top:6px">Total = <b class="gold">140 votos</b></div></div>'
           + '<div class="fx" id="bVw" style="position:absolute;left:0;top:420px;width:900px;height:120px">' + bar("bV", 0, "VOTOS ORDINARIOS (140)", [("B", 71.43, "71,4 %"), ("A", 28.57, "28,6 %")]) + "</div>"
           + ring("exRing", -24, 444, 690, 112, True) + '<div class="note lt fx" id="exN" style="left:30px;top:566px;font-size:46px;transform:rotate(-3deg)">10 % de acciones → 71 % de votos</div>')
    P.append(clip("ex", ex + f'<div id="exR" style="position:absolute;left:700px;top:60px;width:900px;height:700px">{ex2}</div>', "fx", "position:absolute;left:110px;top:150px;width:1700px;height:740px"))
    P.append(clip("one", '<div class="card" style="left:0;top:0;width:820px;height:300px;padding:34px 40px"><div class="k" style="font-size:22px">UNA PERSONA · 1 ACCIÓN CLASE A</div>'
                  '<div class="t" style="font-size:60px;margin-top:14px">1 % del negocio</div><div class="t" style="font-size:60px;margin-top:6px;color:var(--gtx)">1 voto de 140 <span style="font-size:36px;color:rgba(11,27,51,.6)">(≈ 0,7 %)</span></div></div>', "fx", "position:absolute;left:880px;top:330px;width:820px;height:320px"))
    # 5 principiante
    app = ('<div style="position:absolute;left:30px;top:30px;font-weight:800;font-size:18px;letter-spacing:.14em;color:rgba(11,27,51,.55)">APLICACIÓN DE INVERSIÓN · ILUSTRACIÓN</div>'
           '<div style="position:absolute;left:30px;top:80px;width:500px;height:120px;border-radius:18px;background:#fff;box-shadow:0 6px 18px rgba(0,0,0,.08);padding:20px 24px">'
           '<div style="font-weight:800;font-size:32px">Empresa ejemplo</div><div style="font-weight:700;font-size:24px;opacity:.6;margin-top:6px">SÍMBOLO · Precio —</div></div>'
           '<div class="fx" id="apI" style="position:absolute;left:30px;top:230px;width:500px;padding:18px 24px;border-radius:18px;border:4px dashed var(--gold2);font-weight:800;font-size:26px;line-height:1.3">Detrás del símbolo:<br/><span style="color:var(--gtx)">instrumento concreto · derechos concretos</span></div>')
    P.append(clip("app", app, "card fx", "left:110px;top:220px;width:560px;height:420px;transform:rotate(-2deg)"))
    st = ('<div class="cl fx" id="s1" style="top:0;font-size:42px;gap:24px"><div class="n" style="width:74px;height:74px;font-size:38px">1</div>Identifica qué compras: clase o instrumento</div>'
          '<div class="cl fx" id="s2" style="top:110px;font-size:42px;gap:24px"><div class="n" style="width:74px;height:74px;font-size:38px">2</div>Consulta sus derechos en documentos oficiales</div>')
    P.append(clip("steps", st, "fx", "position:absolute;left:760px;top:260px;width:1100px;height:260px"))
    P.append(clip("brk", '<div class="qcard a" style="left:0;top:0;width:640px;font-size:46px"><small style="font-size:20px">DERECHOS DEL INSTRUMENTO</small>Lo que la acción permite</div>'
                  '<div class="qcard b" style="left:700px;top:0;width:640px;font-size:46px"><small style="font-size:20px">CONDICIONES DEL BRÓKER</small>Cómo te facilita votar</div>'
                  '<div class="note lt fx" id="brkN" style="left:700px;top:250px;font-size:46px;transform:rotate(-3deg)">no todos lo hacen igual</div>', "fx", "position:absolute;left:290px;top:520px;width:1400px;height:330px"))
    # 6 cinco preguntas
    qs = ["¿Qué instrumento es?", "¿Qué derechos tiene?", "¿Quién concentra el voto?", "¿Qué riesgos tiene el negocio?", "¿Qué precio estoy pagando?"]
    q = '<div class="B" style="position:absolute;left:0;top:0;font-size:64px">Antes de comprar</div>'
    for k, t in enumerate(qs):
        q += f'<div class="cl fx" id="q{k}" style="top:{110+k*112}px;font-size:50px;gap:28px"><div class="n" style="width:82px;height:82px;font-size:42px">{k+1}</div>{t}</div>'
    q += '<div class="pill fx" id="qP" style="left:1000px;top:330px;padding:20px 32px;font-size:32px;background:var(--ivory);color:var(--navy);white-space:normal;width:620px">Ninguna, por sí sola, dice si es buena o mala inversión. Juntas te ayudan a entender qué compras.</div>'
    P.append(clip("qs", q, "fx", "position:absolute;left:150px;top:180px;width:1700px;height:720px"))
    # 7 conclusión: balanza
    bal = ('<div class="B" style="position:absolute;left:0;top:0;width:1700px;text-align:center;font-size:58px">Voto concentrado: <span class="gold">¿bueno o malo?</span></div>'
           '<div style="position:absolute;left:846px;top:160px;width:8px;height:380px;background:var(--gold);border-radius:4px"></div>'
           '<div style="position:absolute;left:790px;top:530px;width:120px;height:24px;background:var(--gold);border-radius:12px"></div>'
           '<div id="beam" style="position:absolute;left:350px;top:170px;width:1000px;height:10px;background:var(--gold);border-radius:5px;transform-origin:50% 50%"></div>'
           '<div class="qcard a fx" id="pl1" style="left:200px;top:220px;width:520px;font-size:40px;text-align:center"><small style="font-size:20px">PUEDE FAVORECER</small>Continuidad de la estrategia</div>'
           '<div class="qcard b fx" id="pl2" style="left:980px;top:220px;width:520px;font-size:40px;text-align:center"><small style="font-size:20px">PUEDE LIMITAR</small>Influencia de otros accionistas</div>'
           '<div class="pill fx" id="plP" style="left:470px;top:470px;padding:18px 34px;font-size:32px;background:var(--navy);border:3px solid var(--gold);color:var(--ivory)">Un aspecto que evaluar, no un veredicto</div>')
    P.append(clip("bal", bal, "fx", "position:absolute;left:110px;top:170px;width:1700px;height:620px"))
    P.append(clip("cta", '<div class="B" style="font-size:84px;line-height:1.08;text-transform:uppercase;width:1500px">¿Invertirías <span style="display:inline-block;background:var(--gold);color:var(--navy);border-radius:16px;padding:0 20px 6px;transform:rotate(-2deg)">sin voto</span><br/>si confiaras en la dirección?</div>'
                  '<div class="btn fx" id="ctaB" style="left:0;top:270px;width:620px;padding:22px 0;font-size:36px">Comenta tu respuesta</div>'
                  '<svg class="cur fx" id="ctaC" style="left:540px;top:320px" width="70" height="80" viewBox="0 0 70 80"><path d="M8 4 L8 62 L24 48 L36 74 L48 68 L36 44 L58 44 Z" fill="#F4EEDC" stroke="#0B1B33" stroke-width="4"/></svg>'
                  f'<div class="disc" style="left:0;top:430px;width:1000px;text-align:left;font-size:28px">{DISC}</div>', "fx", "position:absolute;left:150px;top:230px;width:1600px;height:520px"))
    P.append(clip("caps", "{CAPS}", "", "left:160px;top:900px;width:1600px;height:140px"))
    return "\n".join(P)
