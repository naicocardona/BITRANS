# Cuerpo vertical 1080×1920 (TikTok y Shorts)
from tq_parts import *
def body_v(V):
    TK = V == "tiktok"; P = []
    P.append('<div id="dots"></div>')
    P.append(clip("brand", LOGO + "<span>TITÁN HOLDING</span>", style="left:50px;top:180px"))
    # gancho + fichas
    P.append(clip("hook", '<div class="l l1" style="font-size:88px">Eres accionista.</div><br/><div class="l l2" style="font-size:88px;margin-left:120px">¿Tienes voto?</div>', "hk", "left:60px;top:300px"))
    fichas = "".join(ficha(f"f{c}", 60 + k * 330, 0, 300, 450, c, 1.0) for k, c in enumerate("ABC"))
    P.append(clip("fich", fichas + '<div class="legend fx" id="leg" style="left:0;top:470px;width:960px;font-size:25px">VOTOS POR ACCIÓN · NO ES PRECIO NI RENTABILIDAD</div>', "", "position:absolute;left:0;top:690px;width:1080px;height:520px"))
    if TK:
        P.append(clip("own", '<div class="pill fx" id="own1" style="left:0;top:0;padding:14px 26px;font-size:32px;background:var(--ivory);color:var(--navy)">✓ Participación económica</div>'
                      '<div class="pill fx" id="own2" style="left:520px;top:0;padding:14px 26px;font-size:32px;background:var(--gold);color:var(--navy)">¿Y el voto?</div>', "", "position:absolute;left:70px;top:582px;width:940px;height:80px"))
    # noticia
    P.append(clip("news", '<div class="k" style="position:absolute;left:44px;top:40px;font-size:24px">META · ANUNCIO DE OCTUBRE 2026</div>'
        '<div class="t" style="position:absolute;left:44px;top:84px;font-size:74px;width:860px">Nueva clase C<br/>de acciones</div>'
        '<div class="pill" style="left:44px;top:262px;padding:12px 26px;font-size:32px;background:var(--navy);color:var(--gold)">Sin voto ordinario*</div>'
        '<div id="tlL" style="position:absolute;left:100px;top:470px;width:740px;height:6px;background:rgba(11,27,51,.2);border-radius:3px"></div>'
        '<div id="tlF" style="position:absolute;left:100px;top:470px;width:740px;height:6px;background:var(--navy);border-radius:3px;transform-origin:0 50%"></div>'
        '<div style="position:absolute;left:84px;top:454px;width:38px;height:38px;border-radius:50%;background:var(--navy)"></div>'
        '<div class="fx" id="d2" style="position:absolute;left:822px;top:454px;width:38px;height:38px;border-radius:50%;background:var(--gold);border:5px solid var(--navy)"></div>'
        '<div style="position:absolute;left:44px;top:510px;width:300px;font-weight:800;font-size:30px">OCT 2026<br/><span style="font-weight:700;font-size:24px;opacity:.7">anunciada</span></div>'
        '<div class="fx" id="d2t" style="position:absolute;left:560px;top:510px;width:340px;text-align:right;font-weight:800;font-size:30px">19 ENE 2027<br/><span style="font-weight:700;font-size:24px;color:var(--gtx)">fecha efectiva prevista</span></div>'
        '<div class="src" style="left:44px;top:640px;width:860px;font-size:20px">*Salvo excepciones previstas en los documentos y la ley · Fuente: documentos de Meta, oct. 2026</div>',
        "card fx", "left:70px;top:330px;width:940px;height:700px"))
    if TK:
        rows = ""
        for k, (c, vz, tx) in enumerate([("A", vbs(1, 70), "1 voto<br/>por acción"), ("B", vbs(10, 34), "10 votos<br/>por acción"),
                                          ("C", '<div class="pie" style="width:70px;height:70px;margin:6px"></div>' + vbs(1, 52, "no"), "Sin voto<br/>ordinario*")]):
            rows += (f'<div class="row fx" id="cr{c}" style="top:{110+k*190}px;height:170px;padding:0 36px;border-top:2px solid rgba(11,27,51,.12)">'
                     f'<div class="B" style="font-size:96px;width:110px">{c}</div><div class="vz" style="display:flex;flex-wrap:wrap;width:330px;justify-content:center">{vz}</div>'
                     f'<div style="margin-left:40px;font-weight:800;font-size:34px;line-height:1.15">{tx}</div></div>')
        P.append(clip("cls", '<div class="k" style="position:absolute;left:36px;top:36px;font-size:24px">SEGÚN SU DOCUMENTACIÓN · VOTOS POR ACCIÓN</div>' + rows +
                      '<div class="src" style="left:36px;top:690px;width:860px;font-size:20px">*Salvo las excepciones previstas · No es precio ni rentabilidad</div>',
                      "card fx", "left:70px;top:330px;width:940px;height:740px"))
    # participación económica ≠ voto
    tb = ('<div style="position:absolute;left:250px;top:40px;width:300px;text-align:center;font-weight:800;font-size:23px;letter-spacing:.08em">PARTICIPACIÓN<br/>ECONÓMICA</div>'
          '<div style="position:absolute;left:580px;top:40px;width:300px;text-align:center;font-weight:800;font-size:23px;letter-spacing:.08em">VOTO<br/>ORDINARIO</div>')
    for k, (c, v) in enumerate([("A", "1"), ("B", "10"), ("C", "✕")]):
        y = 140 + k * 170
        tb += (f'<div class="fx evr" id="ev{c}"><div class="B" style="position:absolute;left:60px;top:{y}px;font-size:86px">{c}</div>'
               f'<div class="tick y" style="position:absolute;left:345px;top:{y+10}px;width:110px;height:96px;font-size:58px">✓</div>'
               f'<div class="tick {"n" if c=="C" else "y"}" style="position:absolute;left:675px;top:{y+10}px;width:110px;height:96px;font-size:{50 if c!="C" else 58}px">{v}</div></div>')
    tb += ring("evRing", 300, 455, 200, 180) + '<div class="note fx" id="evN" style="left:470px;top:640px;font-size:46px;transform:rotate(-4deg)">¡sigue siendo participación!</div>'
    P.append(clip("ev", tb, "card fx", "left:70px;top:330px;width:940px;height:740px"))
    if TK:
        P.append(clip("q2", '<div class="qcard a fx" id="qa" style="left:0;top:0;width:900px;font-size:66px"><small style="font-size:22px">PREGUNTA 1</small>¿Qué participación tengo?</div>'
                      '<div class="qcard b fx" id="qb" style="left:0;top:330px;width:900px;font-size:66px"><small style="font-size:22px">PREGUNTA 2</small>¿Qué decisiones puedo votar?</div>', "", "position:absolute;left:90px;top:380px;width:900px;height:700px"))
        P.append(clip("inf", '<div class="tag" style="left:0;top:0;font-size:22px">EJEMPLO CONCEPTUAL</div>'
                      '<div class="B" style="position:absolute;left:0;top:60px;font-size:70px;line-height:1.02">Tener voto<br/><span class="gold">≠ dirigir la empresa</span></div>'
                      '<div style="position:absolute;left:0;top:300px;font-weight:800;font-size:28px">TUS VOTOS</div>'
                      '<div id="infMe" style="position:absolute;left:0;top:345px;width:14px;height:64px;border-radius:8px;background:var(--gold);box-shadow:0 0 18px rgba(226,183,85,.8)"></div>'
                      '<div style="position:absolute;left:0;top:450px;font-weight:800;font-size:28px">TOTAL DE VOTOS</div>'
                      '<div id="infAll" style="position:absolute;left:0;top:495px;width:900px;height:64px;border-radius:8px;background:repeating-linear-gradient(90deg, rgba(244,238,220,.85) 0 14px, rgba(244,238,220,.35) 14px 18px);transform-origin:0 50%"></div>'
                      '<div class="note lt fx" id="infN" style="left:420px;top:585px;font-size:48px;transform:rotate(-3deg)">tu influencia = tus votos ÷ total</div>',
                      "fx", "position:absolute;left:90px;top:360px;width:900px;height:720px"))
        items = [("Reconocer el nombre", "s"), ("Entender el instrumento", "hi"), ("El negocio", ""), ("Sus riesgos", ""), ("El precio", "")]
    else:
        items = [("El negocio", ""), ("El precio", ""), ("Qué clase de acción es", "hi"), ("Qué derechos incluye", "hi")]
    ck = '<div class="B" style="position:absolute;left:0;top:0;font-size:70px">Antes de comprar</div>'
    for k, (t, c) in enumerate(items):
        tx = f"<s>{t}</s>" if c == "s" else t
        ck += (f'<div class="cl fx {"hi" if c=="hi" else ""}" id="ck{k}" style="top:{120+k*118}px;font-size:42px;gap:24px">'
               f'<div class="n" style="width:76px;height:76px;font-size:40px">{k+1}</div>{tx}</div>')
    if TK: ck += '<div class="note lt fx" id="ckN" style="left:560px;top:132px;font-size:48px;transform:rotate(-4deg)">¡no basta!</div>'
    tail = "Ninguna clase de acción garantiza ganancias" if TK else "No dice si es buena o mala inversión: te ayuda a entender qué compras"
    ck += f'<div class="pill fx" id="ckP" style="left:0;top:{140+len(items)*118}px;padding:16px 28px;font-size:32px;background:var(--ivory);color:var(--navy);white-space:normal;max-width:900px">{tail}</div>'
    P.append(clip("ck", ck, "fx", "position:absolute;left:90px;top:340px;width:900px;height:860px"))
    # cierre
    P.append(clip("cta", '<div class="B" style="font-size:78px;line-height:1.08;text-transform:uppercase">¿Invertirías <span style="display:inline-block;background:var(--gold);color:var(--navy);border-radius:16px;padding:0 18px 6px;transform:rotate(-2deg)">sin voto</span> si confiaras en la dirección?</div>'
                  '<div class="btn fx" id="ctaB" style="left:0;top:430px;width:640px;padding:22px 0;font-size:36px">Comenta tu respuesta</div>'
                  '<svg class="cur fx" id="ctaC" style="left:560px;top:480px" width="70" height="80" viewBox="0 0 70 80"><path d="M8 4 L8 62 L24 48 L36 74 L48 68 L36 44 L58 44 Z" fill="#F4EEDC" stroke="#0B1B33" stroke-width="4"/></svg>'
                  f'<div class="disc" style="left:0;top:600px;width:900px;font-size:26px">{DISC}</div>', "fx", "position:absolute;left:90px;top:400px;width:900px;height:700px"))
    P.append(clip("caps", "{CAPS}", "", "left:70px;top:1360px;width:940px;height:220px"))
    return "\n".join(P)
