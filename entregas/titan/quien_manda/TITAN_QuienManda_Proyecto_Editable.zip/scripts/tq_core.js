const tl = gsap.timeline({ paused: true });
const EZ = "power3.out";
function inn(sel, t, o) { o = o || {}; tl.fromTo(sel, { opacity: 0, y: o.y === undefined ? 24 : o.y, x: o.x || 0 }, { opacity: 1, y: 0, x: 0, duration: o.d || 0.45, ease: EZ, stagger: o.st || 0, immediateRender: false }, t); }
function out(sel, t, d) { tl.to(sel, { opacity: 0, duration: d || 0.3, ease: "power2.in" }, t); }
function pop(sel, t, st) { tl.fromTo(sel, { opacity: 0, scale: 0.84, rotation: -3 }, { opacity: 1, scale: 1, rotation: 0, duration: 0.5, ease: "back.out(1.7)", stagger: st || 0, immediateRender: false }, t); }
function lit(sel, t, st) { document.querySelectorAll(sel).forEach((e, i) => { const c = e.getAttribute("class"); tl.set(e, { attr: { class: c + " on" } }, t + i * (st || 0.08)); }); }
function hi(sel, t, on) { document.querySelectorAll(sel).forEach(e => { const c = e.getAttribute("class").replace(/\s?hi\b/g, ""); tl.set(e, { attr: { class: on ? c + " hi" : c } }, t); }); }
function ring(sel, t, d) {
  tl.fromTo(sel, { opacity: 0 }, { opacity: 1, duration: 0.05, immediateRender: false }, t);
  tl.fromTo(sel + " path", { attr: { "stroke-dashoffset": 1 } }, { attr: { "stroke-dashoffset": 0 }, duration: d || 0.7, ease: "power2.out", immediateRender: false }, t);
}
function grow(sel, t, d, o) { tl.fromTo(sel, { scaleX: 0 }, { scaleX: 1, duration: d || 0.8, ease: "power2.out", immediateRender: true, transformOrigin: (o || "0% 50%") }, t); }
function scene(sel, t0, t1, y) { inn(sel, t0 - 0.12, { y: y === undefined ? 34 : y, d: 0.5 }); if (t1) out(sel, t1 - 0.32); }
// subtítulos palabra por palabra (grupo visible + palabra activa en caja dorada)
CG.forEach(([a, b, ws], i) => {
  tl.set("#cg" + i, { opacity: 1 }, a); tl.set("#cg" + i, { opacity: 0 }, b);
  ws.forEach(([s, e], j) => { const el = document.getElementById("cw" + i + "_" + j), c = el.getAttribute("class");
    tl.set(el, { attr: { class: c + " on" } }, s); tl.set(el, { attr: { class: c } }, e); });
});
