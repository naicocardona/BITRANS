// ===== horizontal (YouTube largo) =====
function chip(id, t0, t1) { inn(id, t0, { y: -10 }); if (t1) out(id, t1 - 0.3); }
// 1 · gancho
tl.fromTo("#hook .l1", { opacity: 0, x: -60 }, { opacity: 1, x: 0, duration: 0.35, ease: EZ, immediateRender: true }, 0);
tl.fromTo("#hook .l2", { opacity: 0, x: 60 }, { opacity: 1, x: 0, duration: 0.35, ease: EZ, immediateRender: true }, 0.12);
pop(["#fA", "#fB", "#fC"], 0.05, 0.12); lit("#fA .lt", 0.55); lit("#fB .lt", 0.8, 0.06); inn("#leg", 1.3, { y: 10 });
tl.fromTo("#fich", { scale: 1.04 }, { scale: 1, duration: 4, ease: "sine.out", immediateRender: true, transformOrigin: "50% 50%" }, 0);
pop("#neq", A.neq);
out(["#hook", "#fich", "#neq"], A.news - 0.32);
// 2 · la noticia
chip("#sec1", A.news - 0.2, A.cls);
scene("#news", A.news, A.myth); grow("#tlF", A.news + 0.4, Math.max(0.6, A.d2 - A.news - 0.4)); pop("#d2", A.d2); inn("#d2t", A.d2 + 0.1);
tl.fromTo("#doc", { opacity: 0, x: 80, rotation: 6 }, { opacity: 1, x: 0, rotation: 2, duration: 0.6, ease: EZ, immediateRender: false }, A.doc); out("#doc", A.myth - 0.32);
tl.fromTo("#hl2", { opacity: 0, scaleX: 0 }, { opacity: 1, scaleX: 1, duration: 0.5, transformOrigin: "0% 50%", immediateRender: false }, A.hl2);
tl.fromTo("#hl1", { opacity: 0, scaleX: 0 }, { opacity: 1, scaleX: 1, duration: 0.5, transformOrigin: "0% 50%", immediateRender: false }, A.hl1);
scene("#myth", A.myth, A.cls); inn("#m1", A.m1, { x: -30, y: 0 }); inn("#m2", A.m2, { x: -30, y: 0 }); pop("#m3", A.m3);
// 3 · tres clases
chip("#sec2", A.cls - 0.2, A.ex);
scene("#cls", A.cls, A.avail); pop("#gA", A.gA); lit("#gA .lt", A.gA + 0.4); pop("#gB", A.gB); lit("#gB .lt", A.gB + 0.4, 0.06); pop("#gC", A.gC);
scene("#not", A.not, A.avail, 0); inn("#n1", A.n1); inn("#n2", A.n2); inn("#n3", A.n3); pop("#n4", A.n4);
scene("#avail", A.avail, A.ex); pop("#av1", A.av1);
// 4 · ejemplo conceptual
chip("#sec3", A.ex - 0.2, A.app);
scene("#ex", A.ex, A.app, 0);
tl.to(".tok", { opacity: 1, duration: 0.12, stagger: 0.012 }, A.tok);
["B", "A", "C"].forEach(c => tl.fromTo(".t" + c + ".tok", { scale: 1 }, { scale: 1.18, duration: 0.25, yoyo: true, repeat: 1, ease: "power1.inOut", stagger: 0.004, immediateRender: false }, A["k" + c]));
inn("#lgd", A.kC + 0.8, { y: 10 });
tl.set("#exR", { opacity: 1 }, 0);
["B", "A", "C"].forEach((c, k) => grow("#bE" + c, A.bE + k * 0.6, 0.6));
inn("#math", A.mB - 0.1, { y: 0 }); inn("#m_b", A.mB); inn("#m_a", A.mA); inn("#m_c", A.mC); pop("#m_t", A.mT);
inn("#bVw", A.bV, { y: 0 }); grow("#bVB", A.bV + 0.3, 0.8); grow("#bVA", A.bV + 1.1, 0.6);
ring("#exRing", A.exR); inn("#exN", A.exR + 0.5, { y: 0 });
out("#exR", A.one - 0.3); pop("#one", A.one);
tl.to(".tok", { opacity: 0.25, duration: 0.3 }, A.one); tl.to("#tk10", { opacity: 1, scale: 1.35, boxShadow: "0 0 26px rgba(226,183,85,.95)", duration: 0.4 }, A.one + 0.1);
out("#one", A.app - 0.32);
// 5 · para quien empieza
chip("#sec4", A.app - 0.2, A.qs);
tl.fromTo("#app", { opacity: 0, y: 40, rotation: -6 }, { opacity: 1, y: 0, rotation: -2, duration: 0.6, ease: EZ, immediateRender: false }, A.app); out("#app", A.brk - 0.32);
pop("#apI", A.apI);
scene("#steps", A.s1, A.qs, 0); inn("#s1", A.s1, { x: -30, y: 0 }); inn("#s2", A.s2, { x: -30, y: 0 });
tl.to("#steps", { y: -90, duration: 0.5, ease: "power2.inOut" }, A.brk - 0.3);
scene("#brk", A.brk, A.qs); inn("#brkN", A.brkN, { y: 0 });
// 6 · cinco preguntas
chip("#sec5", A.qs - 0.2, A.bal);
scene("#qs", A.qs, A.bal, 0);
A.qT.forEach((t, k) => { inn("#q" + k, t, { x: -30, y: 0 }); hi("#q" + k, t, true); if (k) hi("#q" + (k - 1), t, false); });
hi("#q4", A.qP, false); pop("#qP", A.qP);
// 7 · conclusión
chip("#sec6", A.bal - 0.2, null);
scene("#bal", A.bal, A.cta);
pop("#pl1", A.pl1); tl.to("#beam", { rotation: -5, duration: 0.6, ease: "power2.inOut" }, A.pl1);
pop("#pl2", A.pl2); tl.to("#beam", { rotation: 5, duration: 0.8, ease: "power2.inOut" }, A.pl2);
tl.to("#beam", { rotation: 0, duration: 0.8, ease: "power2.inOut" }, A.plP); pop("#plP", A.plP);
tl.to(["#pl1"], { y: 0, duration: 0.1 }, A.pl1);
scene("#cta", A.cta, null);
pop("#ctaB", A.cta + 1.6); inn("#ctaC", A.cta + 2.1, { x: 40, y: 40 }); tl.to("#ctaB", { scale: 0.95, duration: 0.1, yoyo: true, repeat: 1 }, A.cta + 2.6);
tl.to({}, { duration: 0.01 }, DUR - 0.01);
window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl;
