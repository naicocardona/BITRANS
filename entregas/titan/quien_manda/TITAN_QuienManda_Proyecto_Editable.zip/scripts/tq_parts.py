# Piezas HTML del paquete TITÁN «¿Quién manda?» (vertical y horizontal)
LOGO = '<div class="lg" data-layout-allow-overflow><img src="assets/brand/logo.jpg" alt="TITÁN Holding" /></div>'
def clip(i, body, cls="", style="", dur="{DUR}", extra=""):
    return f'<div id="{i}" class="clip {cls}" data-start="0" data-duration="{dur}" data-track-index="{{TI}}" style="{style}" {extra}>{body}</div>'
def vbs(n, size, kind="on"):
    k = "vb lt" if kind == "on" else "vb no"
    return "".join(f'<div class="{k}" style="width:{size}px;height:{size}px;margin:{size//7}px"></div>' for _ in range(n))
def ficha(i, x, y, w, h, cls, s):
    hd = int(s * 40); ft = int(s * 27)
    if cls == "A": vz, ftx = vbs(1, int(118 * s)), "<b>1 voto</b><br/>por acción"
    elif cls == "B": vz, ftx = vbs(10, int(42 * s)), "<b>10 votos</b><br/>por acción"
    else:
        vz = f'<div class="pie" style="width:{int(96*s)}px;height:{int(96*s)}px;margin:{int(8*s)}px"></div>' + vbs(1, int(62 * s), "no")
        ftx = "<i>Participación<br/>económica</i><br/>sin voto ordinario"
    return (f'<div class="fc fx" id="{i}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;padding-top:{int(24*s)}px">'
            f'<div class="h" style="font-size:{hd}px">CLASE {cls}</div>'
            f'<div class="vz" style="width:{w-30}px;height:{int(h*0.48)}px;margin-top:{int(10*s)}px">{vz}</div>'
            f'<div class="f" style="font-size:{ft}px;margin-top:{int(8*s)}px">{ftx}</div></div>')
def ring(i, x, y, w, h, lt=False):
    return (f'<svg class="ring fx {"lt" if lt else ""}" id="{i}" style="left:{x}px;top:{y}px" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'
            f'<path d="M{w*.12:.0f} {h*.18:.0f} C {w*.4:.0f} {-h*.06:.0f}, {w*.98:.0f} {h*.02:.0f}, {w*.97:.0f} {h*.5:.0f} S {w*.55:.0f} {h*1.02:.0f}, {w*.2:.0f} {h*.9:.0f} S {-w*.02:.0f} {h*.35:.0f}, {w*.22:.0f} {h*.1:.0f}" pathLength="1" stroke-dasharray="1" stroke-dashoffset="1"/></svg>')
CTA_Q = '¿Invertirías <span class="gbox">sin voto</span> si confiaras en la dirección?'
DISC = "Contenido educativo · No es recomendación de inversión"
