// ===== vertical (TikTok / Shorts) =====
const TK = V === "tiktok";
tl.fromTo("#hook .l1", { opacity: 0, x: -60 }, { opacity: 1, x: 0, duration: 0.35, ease: EZ, immediateRender: true }, 0);
tl.fromTo("#hook .l2", { opacity: 0, x: 60 }, { opacity: 1, x: 0, duration: 0.35, ease: EZ, immediateRender: true }, 0.12);
pop(["#fA", "#fB", "#fC"], 0.05, 0.12);
lit("#fA .lt", 0.55); lit("#fB .lt", 0.8, 0.06); inn("#leg", 1.3, { y: 10 });
tl.fromTo("#fich", { scale: 1.04 }, { scale: 1, duration: 3, ease: "sine.out", immediateRender: true, transformOrigin: "50% 50%" }, 0);
if (TK) {
  scene("#own", A.own1, null, 0); inn("#own1", A.own1 + 0.1); pop("#own2", A.own2);
  tl.fromTo("#fC", { boxShadow: "0 26px 60px rgba(0,0,0,.45)" }, { boxShadow: "0 0 0 6px rgba(226,183,85,.9), 0 26px 60px rgba(0,0,0,.45)", duration: 0.3, yoyo: true, repeat: 3, immediateRender: false }, A.own2 + 0.3);
  out(["#hook", "#own", "#fich"], A.news - 0.32);
} else out(["#hook", "#fich"], A.news - 0.32);
scene("#news", A.news, TK ? A.cls : A.ev);
grow("#tlF", A.news + 0.3, Math.max(0.6, A.d2 - A.news - 0.3));
pop("#d2", A.d2); inn("#d2t", A.d2 + 0.1);
if (TK) {
  scene("#cls", A.cls, A.ev); inn("#crA", A.cA); lit("#crA .lt", A.cA + 0.3); inn("#crB", A.cB); lit("#crB .lt", A.cB + 0.2, 0.05); inn("#crC", A.cC);
}
scene("#ev", A.ev, TK ? A.q2 : A.ck);
inn(["#evA", "#evB", "#evC"], A.ev + 0.3, { st: 0.25 });
ring("#evRing", A.evR); inn("#evN", A.evR + 0.4, { y: 0 });
if (TK) {
  scene("#q2", A.q2, A.inf); inn("#qa", A.qa); inn("#qb", A.qb);
  scene("#inf", A.inf, A.ck); grow("#infAll", A.inf + 0.4, 1.2); tl.fromTo("#infMe", { scaleY: 0 }, { scaleY: 1, duration: 0.4, immediateRender: true }, A.inf + 1.6); inn("#infN", A.infN, { y: 0 });
}
scene("#ck", A.ck, A.cta);
A.ckT.forEach((t, k) => { inn("#ck" + k, t, { x: -30, y: 0 }); });
if (TK) inn("#ckN", A.ckT[0] + 0.8, { y: 0 });
pop("#ckP", A.ckP);
scene("#cta", A.cta, null);
pop("#ctaB", A.cta + 1.6); inn("#ctaC", A.cta + 2.1, { x: 40, y: 40 });
tl.to("#ctaB", { scale: 0.95, duration: 0.1, yoyo: true, repeat: 1 }, A.cta + 2.6);
tl.to({}, { duration: 0.01 }, DUR - 0.01);
window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl;
